import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';
import 'package:study_tracker_app/core/services/encryption_service.dart';

class BackupService {
  static final BackupService instance = BackupService._init();

  BackupService._init();

  Future<String> createBackup() async {
    final db = DatabaseHelper.instance;
    final data = await db.exportAllData();
    
    // Encrypt sensitive data
    final encryptionService = EncryptionService.instance;
    final encryptedData = encryptionService.encryptJson(data);
    
    final backup = {
      'version': '1.0.0',
      'timestamp': DateTime.now().toIso8601String(),
      'data': encryptedData,
    };
    
    return jsonEncode(backup);
  }

  Future<void> saveBackupToFile() async {
    final backup = await createBackup();
    final directory = await getApplicationDocumentsDirectory();
    final file = await File('${directory.path}/study_tracker_backup_${DateTime.now().millisecondsSinceEpoch}.json').create();
    await file.writeAsString(backup);
  }

  Future<void> shareBackup() async {
    final backup = await createBackup();
    final directory = await getApplicationDocumentsDirectory();
    final file = await File('${directory.path}/study_tracker_backup_${DateTime.now().millisecondsSinceEpoch}.json').create();
    await file.writeAsString(backup);
    
    await Share.shareXFiles([XFile(file.path)], text: 'Study Tracker Backup');
  }

  Future<void> restoreFromBackup(String backupJson) async {
    final backup = jsonDecode(backupJson) as Map<String, dynamic>;
    final encryptionService = EncryptionService.instance;
    final data = encryptionService.decryptJson(backup['data'] as String);
    
    final db = DatabaseHelper.instance;
    final database = await db.database;
    
    // Clear existing data
    await database.delete('tasks');
    await database.delete('subtasks');
    await database.delete('routines');
    await database.delete('routine_blocks');
    await database.delete('diary_entries');
    await database.delete('alarms');
    await database.delete('countdowns');
    await database.delete('app_block_rules');
    await database.delete('time_slots');
    await database.delete('task_failures');
    
    // Restore data
    for (var task in data['tasks'] as List) {
      await database.insert('tasks', task, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    
    for (var subtask in data['subtasks'] as List) {
      await database.insert('subtasks', subtask, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    
    for (var routine in data['routines'] as List) {
      await database.insert('routines', routine, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    
    for (var block in data['routine_blocks'] as List) {
      await database.insert('routine_blocks', block, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    
    for (var entry in data['diary_entries'] as List) {
      await database.insert('diary_entries', entry, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    
    for (var alarm in data['alarms'] as List) {
      await database.insert('alarms', alarm, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    
    for (var countdown in data['countdowns'] as List) {
      await database.insert('countdowns', countdown, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    
    for (var rule in data['app_block_rules'] as List) {
      await database.insert('app_block_rules', rule, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    
    for (var slot in data['time_slots'] as List) {
      await database.insert('time_slots', slot, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    
    for (var failure in data['task_failures'] as List) {
      await database.insert('task_failures', failure, conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }
}


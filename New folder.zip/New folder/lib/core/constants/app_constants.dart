class AppConstants {
  // Subject Colors
  static const Map<String, String> subjectColors = {
    'Maths': '#2196F3',
    'Physics': '#FF5722',
    'Chemistry': '#4CAF50',
    'Biology': '#8BC34A',
    'English': '#9C27B0',
    'History': '#FF9800',
    'Geography': '#00BCD4',
    'Computer': '#E91E63',
  };

  // Categories
  static const List<String> categories = [
    'Study',
    'Personal',
    'Health',
    'Routine',
    'Exam',
  ];

  // Focus Timer Presets
  static const List<int> focusTimerPresets = [25, 45, 60, 90, 120];

  // Reason Templates
  static const List<String> reasonTemplates = [
    'Lazy',
    'Tired',
    'Forgot',
    'Procrastinated',
    'Busy with other work',
    'Not feeling well',
    'Emergency',
    'Other',
  ];

  // Promise Types
  static const List<String> promiseTypes = [
    'Add extra study time later',
    'Block favourite app for hours',
    'No entertainment until task completed',
    'Complete double tasks tomorrow',
    'Wake up earlier tomorrow',
  ];

  // Badge Types
  static const Map<String, int> badgeRequirements = {
    '7-day streak': 7,
    '30-day warrior': 30,
    '100 tasks completed': 100,
    'Study master': 1000, // minutes
    'Routine follower': 14, // days
  };

  // Points System
  static const int pointsPerTask = 10;
  static const int pointsPerRoutine = 5;
  static const int pointsPerDayStreak = 20;
  static const int pointsPerHourStudy = 50;

  // Alarm Mission Defaults
  static const int defaultMathDifficulty = 3;
  static const int defaultShakeCount = 50;
  static const int defaultStepCount = 20;
  static const int defaultPuzzleCount = 20;

  // App Blocking
  static const int defaultDailyLimit = 15; // minutes
  static const int defaultPuzzleUnlockCount = 20;
}


import 'package:flutter/material.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';
import 'package:study_tracker_app/features/tasks/presentation/screens/add_task_screen.dart';
import 'package:study_tracker_app/features/tasks/presentation/widgets/timer_widget.dart';

class TaskDetailScreen extends StatefulWidget {
  final Task task;

  const TaskDetailScreen({super.key, required this.task});

  @override
  State<TaskDetailScreen> createState() => _TaskDetailScreenState();
}

class _TaskDetailScreenState extends State<TaskDetailScreen> {
  late Task _task;

  @override
  void initState() {
    super.initState();
    _task = widget.task;
  }

  Future<void> _loadTask() async {
    final tasks = await DatabaseHelper.instance.getTasks();
    final updatedTask = tasks.firstWhere((t) => t.id == _task.id);
    setState(() => _task = updatedTask);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_task.title),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AddTaskScreen(task: _task)),
              ).then((_) => _loadTask());
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _task.title,
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  if (_task.description != null) ...[
                    const SizedBox(height: 8),
                    Text(_task.description!),
                  ],
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Chip(label: Text(_task.category)),
                      if (_task.subject != null) ...[
                        const SizedBox(width: 8),
                        Chip(label: Text(_task.subject!)),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Focus Timer', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  TimerWidget(task: _task),
                ],
              ),
            ),
          ),
          if (_task.subtasks.isNotEmpty) ...[
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Subtasks', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 16),
                    ..._task.subtasks.map((subtask) {
                      return CheckboxListTile(
                        title: Text(subtask.title),
                        value: subtask.isCompleted,
                        onChanged: (value) async {
                          subtask.isCompleted = value ?? false;
                          await DatabaseHelper.instance.updateTask(_task);
                          _loadTask();
                        },
                      );
                    }),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}


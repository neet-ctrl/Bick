import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';
import 'package:study_tracker_app/core/constants/app_constants.dart';

class FailureReasonDialog extends StatefulWidget {
  final Task task;

  const FailureReasonDialog({super.key, required this.task});

  @override
  State<FailureReasonDialog> createState() => _FailureReasonDialogState();
}

class _FailureReasonDialogState extends State<FailureReasonDialog> {
  String? _selectedReason;
  String? _selectedPromise;
  String? _customPromise;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        padding: const EdgeInsets.all(24),
        constraints: const BoxConstraints(maxWidth: 400),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Why didn\'t you complete this task?',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              ...AppConstants.reasonTemplates.map((reason) {
                return RadioListTile<String>(
                  title: Text(reason),
                  value: reason,
                  groupValue: _selectedReason,
                  onChanged: (value) {
                    setState(() => _selectedReason = value);
                  },
                );
              }),
              const SizedBox(height: 24),
              const Text(
                'What will you do about it?',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              ...AppConstants.promiseTypes.map((promise) {
                return RadioListTile<String>(
                  title: Text(promise),
                  value: promise,
                  groupValue: _selectedPromise,
                  onChanged: (value) {
                    setState(() => _selectedPromise = value);
                  },
                );
              }),
              const SizedBox(height: 16),
              TextField(
                decoration: const InputDecoration(
                  labelText: 'Custom Promise (Optional)',
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) => _customPromise = value,
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel'),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton(
                    onPressed: _selectedReason != null && _selectedPromise != null
                        ? () => _saveFailure()
                        : null,
                    child: const Text('Submit'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _saveFailure() async {
    if (_selectedReason == null || _selectedPromise == null) return;

    final failure = TaskFailure(
      id: const Uuid().v4(),
      taskId: widget.task.id,
      date: DateTime.now(),
      reason: _selectedReason!,
      promiseType: _selectedPromise,
      promiseDetails: _customPromise,
      promiseDeadline: DateTime.now().add(const Duration(days: 1)),
    );

    await DatabaseHelper.instance.insertTaskFailure(failure);
    
    if (mounted) {
      Navigator.pop(context, {
        'reason': _selectedReason,
        'promise': _customPromise ?? _selectedPromise,
      });
    }
  }
}


import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:study_tracker_app/core/database/models.dart';

class TaskNotificationService {
  static final TaskNotificationService instance = TaskNotificationService._init();
  final FlutterLocalNotificationsPlugin _notifications = FlutterLocalNotificationsPlugin();

  TaskNotificationService._init();

  Future<void> scheduleTaskReminder(Task task) async {
    if (task.dueDate == null) return;

    await _notifications.zonedSchedule(
      task.id.hashCode,
      task.title,
      task.description ?? 'Task reminder',
      tz.TZDateTime.from(task.dueDate!, tz.local).subtract(const Duration(minutes: 15)),
      NotificationDetails(
        android: AndroidNotificationDetails(
          'task_reminders',
          'Task Reminders',
          channelDescription: 'Notifications for task reminders',
          importance: Importance.high,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher',
          color: _getColorFromHex(task.colorCode),
          styleInformation: BigTextStyleInformation(
            task.description ?? '',
            contentTitle: task.title,
            summaryText: 'Due: ${task.dueDate!.toString()}',
          ),
        ),
        iOS: const DarwinNotificationDetails(),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  Future<void> cancelTaskReminder(String taskId) async {
    await _notifications.cancel(taskId.hashCode);
  }

  Color _getColorFromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}


import 'package:flutter/material.dart';
import 'package:device_apps/device_apps.dart';
import 'package:study_tracker_app/features/app_blocker/services/app_blocker_service.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:uuid/uuid.dart';

class AppBlockerScreen extends StatefulWidget {
  const AppBlockerScreen({super.key});

  @override
  State<AppBlockerScreen> createState() => _AppBlockerScreenState();
}

class _AppBlockerScreenState extends State<AppBlockerScreen> {
  List<Application> _apps = [];
  List<AppBlockRule> _blockRules = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    final apps = await AppBlockerService.instance.getInstalledApps();
    final rules = AppBlockerService.instance.blockRules;
    
    setState(() {
      _apps = apps;
      _blockRules = rules;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('App Blocker'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _buildStudyModeToggle(),
                const SizedBox(height: 16),
                _buildBlockedApps(),
                const SizedBox(height: 16),
                _buildAppList(),
              ],
            ),
    );
  }

  Widget _buildStudyModeToggle() {
    final isStudyMode = AppBlockerService.instance.isStudyMode;
    return Card(
      child: SwitchListTile(
        title: const Text('Study Mode'),
        subtitle: const Text('Block all social media apps'),
        value: isStudyMode,
        onChanged: (value) {
          AppBlockerService.instance.setStudyMode(value);
          setState(() {});
        },
      ),
    );
  }

  Widget _buildBlockedApps() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Blocked Apps', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            _blockRules.isEmpty
                ? const Text('No apps blocked')
                : ..._blockRules.map((rule) {
                    return ListTile(
                      leading: const Icon(Icons.block),
                      title: Text(rule.appName),
                      subtitle: Text('Limit: ${rule.dailyLimitMinutes} min/day'),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () async {
                          await AppBlockerService.instance.removeBlockRule(rule.id);
                          _loadData();
                        },
                      ),
                    );
                  }),
          ],
        ),
      ),
    );
  }

  Widget _buildAppList() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Installed Apps', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            ..._apps.map((app) {
              final isBlocked = _blockRules.any((r) => r.packageName == app.packageName);
              return ListTile(
                leading: app is ApplicationWithIcon
                    ? Image.memory(app.icon, width: 40, height: 40)
                    : const Icon(Icons.android),
                title: Text(app.appName),
                trailing: isBlocked
                    ? const Icon(Icons.block, color: Colors.red)
                    : IconButton(
                        icon: const Icon(Icons.add),
                        onPressed: () => _showBlockDialog(app),
                      ),
              );
            }),
          ],
        ),
      ),
    );
  }

  Future<void> _showBlockDialog(Application app) async {
    final result = await showDialog<AppBlockRule>(
      context: context,
      builder: (context) => _BlockAppDialog(app: app),
    );

    if (result != null) {
      await AppBlockerService.instance.addBlockRule(result);
      _loadData();
    }
  }
}

class _BlockAppDialog extends StatefulWidget {
  final Application app;

  const _BlockAppDialog({required this.app});

  @override
  State<_BlockAppDialog> createState() => _BlockAppDialogState();
}

class _BlockAppDialogState extends State<_BlockAppDialog> {
  int _dailyLimit = 15;
  bool _isStrictMode = false;
  int _puzzleCount = 20;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        padding: const EdgeInsets.all(24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Block ${widget.app.appName}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              TextField(
                decoration: const InputDecoration(labelText: 'Daily Limit (minutes)'),
                keyboardType: TextInputType.number,
                onChanged: (value) => _dailyLimit = int.tryParse(value) ?? 15,
              ),
              SwitchListTile(
                title: const Text('Strict Mode'),
                subtitle: const Text('Require puzzle to unlock'),
                value: _isStrictMode,
                onChanged: (value) => setState(() => _isStrictMode = value),
              ),
              if (_isStrictMode)
                TextField(
                  decoration: const InputDecoration(labelText: 'Puzzle Count'),
                  keyboardType: TextInputType.number,
                  onChanged: (value) => _puzzleCount = int.tryParse(value) ?? 20,
                ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(
                        context,
                        AppBlockRule(
                          id: const Uuid().v4(),
                          packageName: widget.app.packageName,
                          appName: widget.app.appName,
                          dailyLimitMinutes: _dailyLimit,
                          isStrictMode: _isStrictMode,
                          puzzleCount: _puzzleCount,
                        ),
                      );
                    },
                    child: const Text('Block'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}


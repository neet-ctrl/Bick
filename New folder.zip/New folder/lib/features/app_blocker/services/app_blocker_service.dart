import 'dart:async';
import 'package:flutter/material.dart';
import 'package:usage_stats/usage_stats.dart';
import 'package:device_apps/device_apps.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/features/alarms/services/alarm_mission_service.dart';

class AppBlockerService extends ChangeNotifier {
  static final AppBlockerService instance = AppBlockerService._init();
  final AlarmMissionService _puzzleService = AlarmMissionService();
  
  List<AppBlockRule> _blockRules = [];
  Map<String, int> _dailyUsage = {};
  bool _isStudyMode = false;
  bool _isStrictMode = false;
  Timer? _usageTracker;

  AppBlockerService._init() {
    _loadBlockRules();
    _startUsageTracking();
  }

  List<AppBlockRule> get blockRules => _blockRules;
  bool get isStudyMode => _isStudyMode;
  bool get isStrictMode => _isStrictMode;

  Future<void> _loadBlockRules() async {
    _blockRules = await DatabaseHelper.instance.getAppBlockRules();
    notifyListeners();
  }

  void _startUsageTracking() {
    _usageTracker = Timer.periodic(const Duration(seconds: 5), (_) async {
      await _updateUsageStats();
    });
  }

  Future<void> _updateUsageStats() async {
    try {
      final now = DateTime.now();
      final startTime = now.subtract(const Duration(days: 1));
      
      final events = await UsageStats.queryEvents(
        startTime.millisecondsSinceEpoch,
        now.millisecondsSinceEpoch,
      );
      
      for (var event in events) {
        final packageName = event.packageName ?? '';
        if (_dailyUsage.containsKey(packageName)) {
          _dailyUsage[packageName] = (_dailyUsage[packageName]! + 1) * 5; // Approximate seconds
        } else {
          _dailyUsage[packageName] = 5;
        }
      }
      
      await _checkTimeLimits();
    } catch (e) {
      // Handle error
    }
  }

  Future<void> _checkTimeLimits() async {
    for (var rule in _blockRules) {
      final usage = _dailyUsage[rule.packageName] ?? 0;
      if (rule.dailyLimitMinutes > 0 && usage >= rule.dailyLimitMinutes * 60) {
        await _forceCloseApp(rule.packageName);
      }
    }
  }

  Future<void> _forceCloseApp(String packageName) async {
    try {
      // Force close app - requires system permissions
      // This is a placeholder - actual implementation depends on Android version
    } catch (e) {
      // Handle error
    }
  }

  Future<bool> canOpenApp(String packageName) async {
    // Check if app is whitelisted
    final whitelisted = _blockRules.where((r) => r.isWhitelisted && r.packageName == packageName).isNotEmpty;
    if (whitelisted) return true;

    // Check if app is blocked
    final blocked = _blockRules.where((r) => r.packageName == packageName).isNotEmpty;
    if (!blocked) return true;

    // Check time slots
    final now = DateTime.now();
    for (var rule in _blockRules) {
      if (rule.packageName == packageName) {
        for (var slot in rule.blockedTimeSlots) {
          final currentTime = TimeOfDay.fromDateTime(now);
          final startTime = TimeOfDay(hour: slot.startHour, minute: slot.startMinute);
          final endTime = TimeOfDay(hour: slot.endHour, minute: slot.endMinute);
          
          if (_isTimeInRange(currentTime, startTime, endTime)) {
            if (rule.isStrictMode) {
              return await _solvePuzzle(rule.puzzleCount);
            }
            return false;
          }
        }
      }
    }

    // Check daily limit
    final rule = _blockRules.firstWhere((r) => r.packageName == packageName);
    if (rule.dailyLimitMinutes > 0) {
      final usage = _dailyUsage[packageName] ?? 0;
      if (usage >= rule.dailyLimitMinutes * 60) {
        if (rule.isStrictMode) {
          return await _solvePuzzle(rule.puzzleCount);
        }
        return false;
      }
    }

    return true;
  }

  bool _isTimeInRange(TimeOfDay current, TimeOfDay start, TimeOfDay end) {
    final currentMinutes = current.hour * 60 + current.minute;
    final startMinutes = start.hour * 60 + start.minute;
    final endMinutes = end.hour * 60 + end.minute;
    
    if (startMinutes <= endMinutes) {
      return currentMinutes >= startMinutes && currentMinutes <= endMinutes;
    } else {
      return currentMinutes >= startMinutes || currentMinutes <= endMinutes;
    }
  }

  Future<bool> _solvePuzzle(int count) async {
    // Show puzzle screen and verify
    // This should be handled in UI
    return false; // Placeholder
  }

  Future<void> addBlockRule(AppBlockRule rule) async {
    await DatabaseHelper.instance.insertAppBlockRule(rule);
    _blockRules.add(rule);
    notifyListeners();
  }

  Future<void> removeBlockRule(String id) async {
    _blockRules.removeWhere((r) => r.id == id);
    await DatabaseHelper.instance.database.then((db) {
      db.delete('app_block_rules', where: 'id = ?', whereArgs: [id]);
    });
    notifyListeners();
  }

  void setStudyMode(bool enabled) {
    _isStudyMode = enabled;
    notifyListeners();
  }

  void setStrictMode(bool enabled) {
    _isStrictMode = enabled;
    notifyListeners();
  }

  Future<List<Application>> getInstalledApps() async {
    return await DeviceApps.getInstalledApplications(
      includeSystemApps: false,
      onlyAppsWithLaunchIntent: true,
    );
  }

  void dispose() {
    _usageTracker?.cancel();
    super.dispose();
  }
}


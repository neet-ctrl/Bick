import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sensors_plus/sensors_plus.dart';

class ShakeDetectorWidget extends StatefulWidget {
  final int requiredShakes;
  final VoidCallback onComplete;

  const ShakeDetectorWidget({
    super.key,
    required this.requiredShakes,
    required this.onComplete,
  });

  @override
  State<ShakeDetectorWidget> createState() => _ShakeDetectorWidgetState();
}

class _ShakeDetectorWidgetState extends State<ShakeDetectorWidget> {
  StreamSubscription<AccelerometerEvent>? _subscription;
  int _shakeCount = 0;
  double _lastMagnitude = 0.0;

  @override
  void initState() {
    super.initState();
    _startDetecting();
  }

  void _startDetecting() {
    _subscription = accelerometerEventStream().listen((event) {
      final magnitude = (event.x * event.x + event.y * event.y + event.z * event.z).sqrt();
      final delta = (magnitude - _lastMagnitude).abs();
      
      if (delta > 15 && magnitude > 20) {
        setState(() {
          _shakeCount++;
        });
        
        if (_shakeCount >= widget.requiredShakes) {
          widget.onComplete();
        }
      }
      
      _lastMagnitude = magnitude;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text(
            'Shake Your Phone!',
            style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 48),
          Container(
            width: 200,
            height: 200,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(0.1),
              border: Border.all(color: Colors.white, width: 4),
            ),
            child: Center(
              child: Text(
                '$_shakeCount/${widget.requiredShakes}',
                style: const TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          const SizedBox(height: 32),
          LinearProgressIndicator(
            value: _shakeCount / widget.requiredShakes,
            backgroundColor: Colors.grey[800],
            valueColor: const AlwaysStoppedAnimation<Color>(Colors.green),
            minHeight: 8,
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}


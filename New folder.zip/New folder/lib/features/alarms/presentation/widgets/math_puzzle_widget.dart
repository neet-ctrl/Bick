import 'dart:math';
import 'package:flutter/material.dart';

class MathPuzzleWidget extends StatefulWidget {
  final int difficulty;
  final VoidCallback onComplete;

  const MathPuzzleWidget({
    super.key,
    required this.difficulty,
    required this.onComplete,
  });

  @override
  State<MathPuzzleWidget> createState() => _MathPuzzleWidgetState();
}

class _MathPuzzleWidgetState extends State<MathPuzzleWidget> {
  final Random _random = Random();
  final TextEditingController _answerController = TextEditingController();
  int _currentProblem = 0;
  int _num1 = 0;
  int _num2 = 0;
  String _operator = '+';
  int _correctAnswer = 0;

  @override
  void initState() {
    super.initState();
    _generateProblem();
  }

  void _generateProblem() {
    _num1 = _random.nextInt(100) + 1;
    _num2 = _random.nextInt(100) + 1;
    final opIndex = _random.nextInt(3);
    
    switch (opIndex) {
      case 0:
        _operator = '+';
        _correctAnswer = _num1 + _num2;
        break;
      case 1:
        _operator = '-';
        _correctAnswer = _num1 - _num2;
        break;
      case 2:
        _operator = '×';
        _correctAnswer = _num1 * _num2;
        break;
    }
    
    _answerController.clear();
  }

  void _checkAnswer() {
    final userAnswer = int.tryParse(_answerController.text);
    if (userAnswer == _correctAnswer) {
      setState(() {
        _currentProblem++;
      });
      
      if (_currentProblem >= widget.difficulty) {
        widget.onComplete();
      } else {
        _generateProblem();
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Wrong answer! Try again.'),
          backgroundColor: Colors.red,
        ),
      );
      _answerController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Math Puzzle ${_currentProblem + 1}/${widget.difficulty}',
            style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 48),
          Container(
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                Text(
                  '$_num1 $_operator $_num2 = ?',
                  style: const TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 32),
                SizedBox(
                  width: 200,
                  child: TextField(
                    controller: _answerController,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 32),
                    decoration: InputDecoration(
                      hintText: 'Answer',
                      hintStyle: TextStyle(color: Colors.white.withOpacity(0.5)),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: Colors.white),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: Colors.white),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: Colors.green, width: 2),
                      ),
                    ),
                    onSubmitted: (_) => _checkAnswer(),
                  ),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _checkAnswer,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 16),
                    backgroundColor: Colors.green,
                  ),
                  child: const Text('Submit', style: TextStyle(fontSize: 18)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _answerController.dispose();
    super.dispose();
  }
}


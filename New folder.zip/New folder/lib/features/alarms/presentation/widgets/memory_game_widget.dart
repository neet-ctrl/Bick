import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class MemoryGameWidget extends StatefulWidget {
  final int difficulty;
  final VoidCallback onComplete;

  const MemoryGameWidget({
    super.key,
    required this.difficulty,
    required this.onComplete,
  });

  @override
  State<MemoryGameWidget> createState() => _MemoryGameWidgetState();
}

class _MemoryGameWidgetState extends State<MemoryGameWidget> {
  final Random _random = Random();
  List<int> _sequence = [];
  List<int> _userSequence = [];
  bool _showingSequence = true;
  int _currentLevel = 0;

  @override
  void initState() {
    super.initState();
    _startLevel();
  }

  void _startLevel() {
    _sequence = List.generate(_currentLevel + 1, (_) => _random.nextInt(9) + 1);
    _userSequence = [];
    _showingSequence = true;
    
    _showSequence();
  }

  Future<void> _showSequence() async {
    for (int i = 0; i < _sequence.length; i++) {
      await Future.delayed(const Duration(milliseconds: 500));
      if (mounted) {
        setState(() {});
      }
      await Future.delayed(const Duration(milliseconds: 500));
    }
    setState(() => _showingSequence = false);
  }

  void _onNumberTap(int number) {
    if (_showingSequence) return;
    
    setState(() {
      _userSequence.add(number);
    });
    
    if (_userSequence.length == _sequence.length) {
      if (_userSequence.toString() == _sequence.toString()) {
        _currentLevel++;
        if (_currentLevel >= widget.difficulty) {
          widget.onComplete();
        } else {
          _startLevel();
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Wrong sequence! Try again.'),
            backgroundColor: Colors.red,
          ),
        );
        _startLevel();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Memory Game Level ${_currentLevel + 1}/${widget.difficulty}',
            style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 48),
          if (_showingSequence)
            Text(
              _sequence.join(' '),
              style: const TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold),
            )
          else
            Wrap(
              spacing: 16,
              runSpacing: 16,
              children: List.generate(9, (index) {
                final number = index + 1;
                return GestureDetector(
                  onTap: () => _onNumberTap(number),
                  child: Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                    child: Center(
                      child: Text(
                        '$number',
                        style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                );
              }),
            ),
        ],
      ),
    );
  }
}


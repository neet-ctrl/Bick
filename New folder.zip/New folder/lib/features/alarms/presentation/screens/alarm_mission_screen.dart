import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/features/alarms/services/alarm_service.dart';
import 'package:study_tracker_app/features/alarms/services/alarm_mission_service.dart';
import 'package:study_tracker_app/features/alarms/presentation/widgets/math_puzzle_widget.dart';
import 'package:study_tracker_app/features/alarms/presentation/widgets/memory_game_widget.dart';
import 'package:study_tracker_app/features/alarms/presentation/widgets/shake_detector_widget.dart';
import 'package:study_tracker_app/features/alarms/presentation/widgets/color_tiles_widget.dart';
import 'package:study_tracker_app/features/alarms/presentation/widgets/typing_widget.dart';
import 'dart:math';

class AlarmMissionScreen extends StatefulWidget {
  final StudyAlarm alarm;

  const AlarmMissionScreen({super.key, required this.alarm});

  @override
  State<AlarmMissionScreen> createState() => _AlarmMissionScreenState();
}

class _AlarmMissionScreenState extends State<AlarmMissionScreen> {
  final AlarmMissionService _missionService = AlarmMissionService();
  int _completedMissions = 0;
  bool _canDismiss = false;
  bool _isSnoozed = false;
  Timer? _snoozeTimer;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _startMission();
  }

  void _startMission() {
    // Alarm continues ringing until all missions completed
    // User can snooze but cannot dismiss
  }

  Future<void> _completeMission() async {
    setState(() {
      _completedMissions++;
    });

    if (_completedMissions >= widget.alarm.missionDifficulty) {
      setState(() => _canDismiss = true);
    }
  }

  Future<void> _snoozeAlarm() async {
    if (_isSnoozed) return;
    
    setState(() => _isSnoozed = true);
    // Snooze for 5 minutes
    _snoozeTimer = Timer(const Duration(minutes: 5), () {
      setState(() => _isSnoozed = false);
      // Alarm starts ringing again
    });
  }

  Future<void> _dismissAlarm() async {
    if (!_canDismiss) return;
    
    final alarmService = Provider.of<AlarmService>(context, listen: false);
    await alarmService.stopAlarm();
    
    if (mounted) {
      Navigator.of(context).popUntil((route) => route.isFirst);
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // Prevent back button - must complete mission
        return false;
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Column(
            children: [
              // Alarm Info
              Container(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    Text(
                      widget.alarm.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Complete ${widget.alarm.missionDifficulty} missions to dismiss',
                      style: const TextStyle(color: Colors.white70, fontSize: 16),
                    ),
                    const SizedBox(height: 16),
                    LinearProgressIndicator(
                      value: _completedMissions / widget.alarm.missionDifficulty,
                      backgroundColor: Colors.grey[800],
                      valueColor: const AlwaysStoppedAnimation<Color>(Colors.green),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Progress: $_completedMissions/${widget.alarm.missionDifficulty}',
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                    ),
                  ],
                ),
              ),
              
              // Mission Widget
              Expanded(
                child: _buildMissionWidget(),
              ),
              
              // Action Buttons
              Container(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton.icon(
                      onPressed: _isSnoozed ? null : _snoozeAlarm,
                      icon: const Icon(Icons.snooze),
                      label: const Text('Snooze (5 min)'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange,
                        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                      ),
                    ),
                    ElevatedButton.icon(
                      onPressed: _canDismiss ? _dismissAlarm : null,
                      icon: const Icon(Icons.check_circle),
                      label: const Text('Dismiss'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMissionWidget() {
    switch (widget.alarm.missionType) {
      case AlarmMissionType.math:
        return MathPuzzleWidget(
          difficulty: widget.alarm.missionDifficulty,
          onComplete: _completeMission,
        );
      case AlarmMissionType.memory:
        return MemoryGameWidget(
          difficulty: widget.alarm.missionDifficulty,
          onComplete: _completeMission,
        );
      case AlarmMissionType.shake:
        return ShakeDetectorWidget(
          requiredShakes: widget.alarm.missionDifficulty,
          onComplete: _completeMission,
        );
      case AlarmMissionType.steps:
        return _buildStepsWidget();
      case AlarmMissionType.qrCode:
        return _buildQRCodeWidget();
      case AlarmMissionType.maze:
        return _buildMazeWidget();
      case AlarmMissionType.colorTiles:
        return ColorTilesWidget(
          difficulty: widget.alarm.missionDifficulty,
          onComplete: _completeMission,
        );
      case AlarmMissionType.typing:
        return TypingWidget(
          difficulty: widget.alarm.missionDifficulty,
          onComplete: _completeMission,
        );
      default:
        return const Center(child: Text('Unknown mission type', style: TextStyle(color: Colors.white)));
    }
  }

  Widget _buildStepsWidget() {
    return Center(
      child: Text(
        'Walk ${widget.alarm.missionDifficulty} steps',
        style: const TextStyle(color: Colors.white, fontSize: 24),
      ),
    );
  }

  Widget _buildQRCodeWidget() {
    return const Center(
      child: Text(
        'Scan QR Code',
        style: TextStyle(color: Colors.white, fontSize: 24),
      ),
    );
  }

  Widget _buildMazeWidget() {
    return const Center(
      child: Text(
        'Complete Maze',
        style: TextStyle(color: Colors.white, fontSize: 24),
      ),
    );
  }

  @override
  void dispose() {
    _snoozeTimer?.cancel();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }
}


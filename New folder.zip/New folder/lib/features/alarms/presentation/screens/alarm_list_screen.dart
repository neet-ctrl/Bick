import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';
import 'package:study_tracker_app/features/alarms/services/alarm_service.dart';
import 'package:intl/intl.dart';

class AlarmListScreen extends StatefulWidget {
  const AlarmListScreen({super.key});

  @override
  State<AlarmListScreen> createState() => _AlarmListScreenState();
}

class _AlarmListScreenState extends State<AlarmListScreen> {
  List<StudyAlarm> _alarms = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadAlarms();
  }

  Future<void> _loadAlarms() async {
    setState(() => _isLoading = true);
    final alarms = await DatabaseHelper.instance.getAlarms();
    setState(() {
      _alarms = alarms;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Alarms'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _alarms.isEmpty
              ? _buildEmptyState()
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _alarms.length,
                  itemBuilder: (context, index) {
                    return _AlarmCard(
                      alarm: _alarms[index],
                      onToggle: (alarm) async {
                        alarm.isActive = !alarm.isActive;
                        await DatabaseHelper.instance.database.then((db) {
                          db.update('alarms', {'isActive': alarm.isActive ? 1 : 0}, where: 'id = ?', whereArgs: [alarm.id]);
                        });
                        _loadAlarms();
                      },
                      onDelete: (alarm) async {
                        await AlarmService.instance.cancelAlarm(alarm.id);
                        _loadAlarms();
                      },
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddAlarmDialog(),
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.alarm, size: 64, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Text('No alarms set', style: TextStyle(fontSize: 18, color: Colors.grey[600])),
        ],
      ),
    );
  }

  Future<void> _showAddAlarmDialog() async {
    final result = await showDialog<StudyAlarm>(
      context: context,
      builder: (context) => _AddAlarmDialog(),
    );

    if (result != null) {
      await AlarmService.instance.scheduleAlarm(result);
      _loadAlarms();
    }
  }
}

class _AlarmCard extends StatelessWidget {
  final StudyAlarm alarm;
  final Function(StudyAlarm) onToggle;
  final Function(StudyAlarm) onDelete;

  const _AlarmCard({
    required this.alarm,
    required this.onToggle,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: Switch(
          value: alarm.isActive,
          onChanged: (_) => onToggle(alarm),
        ),
        title: Text(alarm.title),
        subtitle: Text(
          '${DateFormat('hh:mm a').format(alarm.time)} - ${alarm.missionType.toString().split('.').last}',
        ),
        trailing: IconButton(
          icon: const Icon(Icons.delete),
          onPressed: () => onDelete(alarm),
        ),
      ),
    );
  }
}

class _AddAlarmDialog extends StatefulWidget {
  @override
  State<_AddAlarmDialog> createState() => _AddAlarmDialogState();
}

class _AddAlarmDialogState extends State<_AddAlarmDialog> {
  final _titleController = TextEditingController();
  TimeOfDay _selectedTime = TimeOfDay.now();
  AlarmMissionType _missionType = AlarmMissionType.math;
  int _difficulty = 20;
  bool _isLoudMode = false;
  String? _ringtonePath;
  double _volumeLevel = 0.8;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        padding: const EdgeInsets.all(24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _titleController,
                decoration: const InputDecoration(labelText: 'Alarm Title'),
              ),
              const SizedBox(height: 16),
              ListTile(
                title: const Text('Time'),
                trailing: Text(_selectedTime.format(context)),
                onTap: () async {
                  final time = await showTimePicker(
                    context: context,
                    initialTime: _selectedTime,
                  );
                  if (time != null) setState(() => _selectedTime = time);
                },
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<AlarmMissionType>(
                value: _missionType,
                decoration: const InputDecoration(labelText: 'Mission Type'),
                items: AlarmMissionType.values.map((type) {
                  final name = type.toString().split('.').last;
                  final displayName = name == 'colorTiles' 
                      ? 'Color Tiles'
                      : name == 'qrCode'
                          ? 'QR Code'
                          : name[0].toUpperCase() + name.substring(1);
                  return DropdownMenuItem(
                    value: type,
                    child: Text(displayName),
                  );
                }).toList(),
                onChanged: (value) => setState(() => _missionType = value!),
              ),
              const SizedBox(height: 16),
              TextField(
                decoration: const InputDecoration(labelText: 'Difficulty'),
                keyboardType: TextInputType.number,
                onChanged: (value) => _difficulty = int.tryParse(value) ?? 20,
              ),
              SwitchListTile(
                title: const Text('Loud Mode'),
                subtitle: const Text('Maximum volume'),
                value: _isLoudMode,
                onChanged: (value) {
                  setState(() {
                    _isLoudMode = value;
                    if (value) {
                      _volumeLevel = 1.0;
                    }
                  });
                },
              ),
              if (!_isLoudMode) ...[
                const SizedBox(height: 8),
                ListTile(
                  title: const Text('Volume Level'),
                  subtitle: Slider(
                    value: _volumeLevel,
                    min: 0.0,
                    max: 1.0,
                    divisions: 10,
                    label: '${(_volumeLevel * 100).toInt()}%',
                    onChanged: (value) => setState(() => _volumeLevel = value),
                  ),
                  trailing: Text('${(_volumeLevel * 100).toInt()}%'),
                ),
              ],
              ListTile(
                title: const Text('Ringtone'),
                subtitle: Text(_ringtonePath ?? 'Default'),
                trailing: const Icon(Icons.music_note),
                onTap: () async {
                  // Show ringtone picker
                  final result = await _showRingtonePicker();
                  if (result != null) {
                    setState(() => _ringtonePath = result);
                  }
                },
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      final now = DateTime.now();
                      final alarmTime = DateTime(
                        now.year,
                        now.month,
                        now.day,
                        _selectedTime.hour,
                        _selectedTime.minute,
                      );
                      if (alarmTime.isBefore(now)) {
                        alarmTime.add(const Duration(days: 1));
                      }
                      
                      Navigator.pop(
                        context,
                        StudyAlarm(
                          id: const Uuid().v4(),
                          time: alarmTime,
                          title: _titleController.text,
                          missionType: _missionType,
                          missionDifficulty: _difficulty,
                          isLoudMode: _isLoudMode,
                          ringtonePath: _ringtonePath,
                          volumeLevel: _volumeLevel,
                        ),
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<String?> _showRingtonePicker() async {
    // In real implementation, show ringtone picker
    // For now, return null (uses default)
    return null;
  }
                    },
                    child: const Text('Add'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}


import 'package:flutter/material.dart';
import 'package:study_tracker_app/features/diary/services/pdf_export_service.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:share_plus/share_plus.dart';
import 'package:cross_file/cross_file.dart';

class ExportButton extends StatelessWidget {
  final DiaryEntry entry;

  const ExportButton({super.key, required this.entry});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.picture_as_pdf),
      tooltip: 'Export to PDF',
      onPressed: () async {
        try {
          final pdfFile = await PDFExportService.exportDiaryEntry(entry);
          await Share.shareXFiles([XFile(pdfFile.path)], text: 'Diary Entry PDF');
          
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Diary entry exported successfully')),
            );
          }
        } catch (e) {
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Export failed: $e')),
            );
          }
        }
      },
    );
  }
}


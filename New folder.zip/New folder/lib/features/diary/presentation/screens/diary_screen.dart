import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';
import 'package:study_tracker_app/core/services/security_service.dart';
import 'package:study_tracker_app/features/diary/services/pdf_export_service.dart';
import 'package:study_tracker_app/features/diary/presentation/screens/diary_search_screen.dart';
import 'package:share_plus/share_plus.dart';
import 'package:intl/intl.dart';
import 'dart:io';

class DiaryScreen extends StatefulWidget {
  const DiaryScreen({super.key});

  @override
  State<DiaryScreen> createState() => _DiaryScreenState();
}

class _DiaryScreenState extends State<DiaryScreen> {
  DateTime _selectedDate = DateTime.now();
  DiaryEntry? _entry;
  final _morningController = TextEditingController();
  final _eveningController = TextEditingController();
  List<String> _photoPaths = [];
  String? _selectedMood;
  bool _isLocked = false;

  final List<String> _moods = ['😊', '😢', '😴', '😎', '🤔', '😤', '😌', '😍'];

  @override
  void initState() {
    super.initState();
    _loadEntry();
  }

  Future<void> _loadEntry() async {
    if (_isLocked) {
      final unlocked = await SecurityService.instance.authenticate('Unlock Diary');
      if (!unlocked) {
        Navigator.pop(context);
        return;
      }
    }

    final entry = await DatabaseHelper.instance.getDiaryEntry(_selectedDate);
    setState(() {
      _entry = entry;
      if (entry != null) {
        _morningController.text = entry.morningNote ?? '';
        _eveningController.text = entry.eveningNote ?? '';
        _photoPaths = List.from(entry.photoPaths);
        _selectedMood = entry.mood;
        _isLocked = entry.isLocked;
      } else {
        _morningController.clear();
        _eveningController.clear();
        _photoPaths.clear();
        _selectedMood = null;
        _isLocked = false;
      }
    });
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() => _photoPaths.add(image.path));
    }
  }

  Future<void> _saveEntry() async {
    final tasks = await DatabaseHelper.instance.getTasks(date: _selectedDate);
    final completedTasks = tasks.where((t) => t.isCompleted).length;
    final missedTasks = tasks.where((t) => !t.isCompleted && t.dueDate != null && t.dueDate!.isBefore(DateTime.now())).length;
    final totalStudyMinutes = tasks.fold<int>(0, (sum, t) => sum + (t.actualMinutes ?? 0));

    final entry = DiaryEntry(
      id: _entry?.id ?? const Uuid().v4(),
      date: _selectedDate,
      morningNote: _morningController.text.isEmpty ? null : _morningController.text,
      eveningNote: _eveningController.text.isEmpty ? null : _eveningController.text,
      photoPaths: _photoPaths,
      mood: _selectedMood,
      totalStudyMinutes: totalStudyMinutes,
      completedTasksCount: completedTasks,
      missedTasksCount: missedTasks,
      isLocked: _isLocked,
    );

    await DatabaseHelper.instance.insertDiaryEntry(entry);
    
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Diary entry saved')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(DateFormat('MMMM dd, yyyy').format(_selectedDate)),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const DiarySearchScreen()),
              );
            },
          ),
          if (_entry != null)
            ExportButton(entry: _entry!),
          IconButton(
            icon: Icon(_isLocked ? Icons.lock : Icons.lock_open),
            onPressed: () {
              setState(() => _isLocked = !_isLocked);
            },
          ),
          IconButton(
            icon: const Icon(Icons.calendar_today),
            onPressed: () async {
              final date = await showDatePicker(
                context: context,
                initialDate: _selectedDate,
                firstDate: DateTime(2020),
                lastDate: DateTime.now(),
              );
              if (date != null) {
                setState(() => _selectedDate = date);
                _loadEntry();
              }
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSummaryCard(),
          const SizedBox(height: 16),
          _buildMoodSelector(),
          const SizedBox(height: 16),
          _buildMorningNote(),
          const SizedBox(height: 16),
          _buildEveningNote(),
          const SizedBox(height: 16),
          _buildPhotos(),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: _saveEntry,
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
            child: const Text('Save Entry'),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Daily Summary', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildSummaryItem('Tasks', '${_entry?.completedTasksCount ?? 0}'),
                _buildSummaryItem('Missed', '${_entry?.missedTasksCount ?? 0}'),
                _buildSummaryItem('Study Time', '${(_entry?.totalStudyMinutes ?? 0) ~/ 60}h'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryItem(String label, String value) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        Text(label, style: TextStyle(color: Colors.grey[600])),
      ],
    );
  }

  Widget _buildMoodSelector() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Mood', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Wrap(
              spacing: 12,
              children: _moods.map((mood) {
                return ChoiceChip(
                  label: Text(mood, style: const TextStyle(fontSize: 24)),
                  selected: _selectedMood == mood,
                  onSelected: (selected) {
                    setState(() => _selectedMood = selected ? mood : null);
                  },
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMorningNote() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Morning Note', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(
              controller: _morningController,
              decoration: const InputDecoration(
                hintText: 'Write your morning thoughts...',
                border: OutlineInputBorder(),
              ),
              maxLines: 5,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEveningNote() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Evening Note', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(
              controller: _eveningController,
              decoration: const InputDecoration(
                hintText: 'Write your evening thoughts...',
                border: OutlineInputBorder(),
              ),
              maxLines: 5,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPhotos() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Photos', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                IconButton(
                  icon: const Icon(Icons.add_photo_alternate),
                  onPressed: _pickImage,
                ),
              ],
            ),
            const SizedBox(height: 8),
            _photoPaths.isEmpty
                ? const Center(child: Text('No photos'))
                : SizedBox(
                    height: 100,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: _photoPaths.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: Stack(
                            children: [
                              Image.file(File(_photoPaths[index]), width: 100, height: 100, fit: BoxFit.cover),
                              Positioned(
                                top: 0,
                                right: 0,
                                child: IconButton(
                                  icon: const Icon(Icons.close, size: 20),
                                  onPressed: () {
                                    setState(() => _photoPaths.removeAt(index));
                                  },
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}


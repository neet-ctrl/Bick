import 'package:flutter/material.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:intl/intl.dart';

class DiarySearchScreen extends StatefulWidget {
  const DiarySearchScreen({super.key});

  @override
  State<DiarySearchScreen> createState() => _DiarySearchScreenState();
}

class _DiarySearchScreenState extends State<DiarySearchScreen> {
  final _searchController = TextEditingController();
  List<DiaryEntry> _results = [];
  bool _isSearching = false;

  Future<void> _searchDiary(String query) async {
    if (query.isEmpty) {
      setState(() {
        _results = [];
        _isSearching = false;
      });
      return;
    }

    setState(() => _isSearching = true);
    
    // Search by keyword in notes
    final allEntries = <DiaryEntry>[];
    // This would need a search method in database helper
    // For now, placeholder implementation
    
    setState(() {
      _results = allEntries;
      _isSearching = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Search Diary'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search by keyword or date...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          _searchDiary('');
                        },
                      )
                    : null,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onChanged: _searchDiary,
            ),
          ),
          Expanded(
            child: _isSearching
                ? const Center(child: CircularProgressIndicator())
                : _results.isEmpty
                    ? const Center(child: Text('No results found'))
                    : ListView.builder(
                        itemCount: _results.length,
                        itemBuilder: (context, index) {
                          final entry = _results[index];
                          return ListTile(
                            title: Text(DateFormat('MMMM dd, yyyy').format(entry.date)),
                            subtitle: Text(entry.morningNote ?? entry.eveningNote ?? ''),
                            trailing: entry.mood != null ? Text(entry.mood!) : null,
                            onTap: () {
                              Navigator.pushNamed(context, '/diary');
                            },
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}


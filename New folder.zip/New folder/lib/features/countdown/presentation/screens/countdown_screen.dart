import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';
import 'package:study_tracker_app/features/countdown/presentation/widgets/countdown_ring_widget.dart';

class CountdownScreen extends StatefulWidget {
  const CountdownScreen({super.key});

  @override
  State<CountdownScreen> createState() => _CountdownScreenState();
}

class _CountdownScreenState extends State<CountdownScreen> {
  List<Countdown> _countdowns = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadCountdowns();
  }

  Future<void> _loadCountdowns() async {
    setState(() => _isLoading = true);
    final countdowns = await DatabaseHelper.instance.getCountdowns();
    setState(() {
      _countdowns = countdowns;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Countdowns'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _countdowns.isEmpty
              ? _buildEmptyState()
              : GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                  ),
                  itemCount: _countdowns.length,
                  itemBuilder: (context, index) {
                    return CountdownRingWidget(countdown: _countdowns[index]);
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddCountdownDialog(),
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.timer, size: 64, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Text('No countdowns', style: TextStyle(fontSize: 18, color: Colors.grey[600])),
        ],
      ),
    );
  }

  Future<void> _showAddCountdownDialog() async {
    final result = await showDialog<Countdown>(
      context: context,
      builder: (context) => _AddCountdownDialog(),
    );

    if (result != null) {
      await DatabaseHelper.instance.insertCountdown(result);
      _loadCountdowns();
    }
  }
}

class _AddCountdownDialog extends StatefulWidget {
  @override
  State<_AddCountdownDialog> createState() => _AddCountdownDialogState();
}

class _AddCountdownDialogState extends State<_AddCountdownDialog> {
  final _titleController = TextEditingController();
  DateTime _selectedDate = DateTime.now().add(const Duration(days: 30));
  String? _selectedSubject;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        padding: const EdgeInsets.all(24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _titleController,
                decoration: const InputDecoration(labelText: 'Countdown Title'),
              ),
              const SizedBox(height: 16),
              ListTile(
                title: const Text('Target Date'),
                trailing: Text('${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}'),
                onTap: () async {
                  final date = await showDatePicker(
                    context: context,
                    initialDate: _selectedDate,
                    firstDate: DateTime.now(),
                    lastDate: DateTime.now().add(const Duration(days: 365 * 2)),
                  );
                  if (date != null) setState(() => _selectedDate = date);
                },
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _selectedSubject,
                decoration: const InputDecoration(labelText: 'Subject (Optional)'),
                items: ['Maths', 'Physics', 'Chemistry', 'Biology'].map((s) {
                  return DropdownMenuItem(value: s, child: Text(s));
                }).toList(),
                onChanged: (value) => setState(() => _selectedSubject = value),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(
                        context,
                        Countdown(
                          id: const Uuid().v4(),
                          title: _titleController.text,
                          targetDate: _selectedDate,
                          subject: _selectedSubject,
                        ),
                      );
                    },
                    child: const Text('Add'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}


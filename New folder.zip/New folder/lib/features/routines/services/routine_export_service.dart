import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:study_tracker_app/core/database/models.dart';

class RoutineExportService {
  static Future<File> exportRoutines(List<Routine> routines) async {
    final exportData = {
      'exportDate': DateTime.now().toIso8601String(),
      'totalRoutines': routines.length,
      'routines': routines.map((routine) => routine.toJson()).toList(),
    };

    final jsonString = jsonEncode(exportData);
    final directory = await getTemporaryDirectory();
    final file = File('${directory.path}/routines_export_${DateTime.now().millisecondsSinceEpoch}.json');
    await file.writeAsString(jsonString);
    
    return file;
  }

  static Future<void> shareRoutines(List<Routine> routines) async {
    final file = await exportRoutines(routines);
    await Share.shareXFiles([XFile(file.path)], text: 'Routines Export');
  }
}


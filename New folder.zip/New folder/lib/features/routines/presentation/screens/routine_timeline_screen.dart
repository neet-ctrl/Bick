import 'package:flutter/material.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/shared/widgets/animated_timeline.dart';
import 'package:study_tracker_app/features/routines/services/routine_export_service.dart';
import 'package:intl/intl.dart';

class RoutineTimelineScreen extends StatefulWidget {
  const RoutineTimelineScreen({super.key});

  @override
  State<RoutineTimelineScreen> createState() => _RoutineTimelineScreenState();
}

class _RoutineTimelineScreenState extends State<RoutineTimelineScreen> {
  Routine? _activeRoutine;
  List<RoutineBlock> _todayBlocks = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadRoutine();
  }

  Future<void> _loadRoutine() async {
    setState(() => _isLoading = true);
    final routines = await DatabaseHelper.instance.getRoutines();
    _activeRoutine = routines.firstWhere((r) => r.isActive, orElse: () => routines.isNotEmpty ? routines.first : Routine(
      id: '',
      name: 'Default',
      profileType: 'School Days',
      createdAt: DateTime.now(),
    ));
    
    if (_activeRoutine != null) {
      _todayBlocks = List.from(_activeRoutine!.blocks);
      // Add isCompleted property check
      for (var block in _todayBlocks) {
        // Initialize completion status
      }
      _autoShiftRoutine();
    }
    
    setState(() => _isLoading = false);
  }

  void _autoShiftRoutine() {
    final now = DateTime.now();
    final currentTime = TimeOfDay.fromDateTime(now);
    
    for (var block in _todayBlocks) {
      final blockTime = block.startTime;
      final blockMinutes = blockTime.hour * 60 + blockTime.minute;
      final currentMinutes = currentTime.hour * 60 + currentTime.minute;
      
      if (blockMinutes < currentMinutes) {
        // Shift this block and subsequent blocks
        final delay = currentMinutes - blockMinutes;
        block.startHour = currentTime.hour;
        block.startMinute = currentTime.minute;
      }
    }
  }

  double _calculateProgress() {
    if (_todayBlocks.isEmpty) return 0.0;
    final completed = _todayBlocks.where((b) => b.isCompleted).length;
    return completed / _todayBlocks.length;
  }

  Future<void> _toggleBlockComplete(RoutineBlock block) async {
    block.isCompleted = !block.isCompleted;
    await DatabaseHelper.instance.database.then((db) {
      db.update('routine_blocks', {
        'isCompleted': block.isCompleted ? 1 : 0,
      }, where: 'id = ?', whereArgs: [block.id]);
    });
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Today\'s Routine'),
        actions: [
          IconButton(
            icon: const Icon(Icons.upload_file),
            tooltip: 'Export Routine',
            onPressed: () async {
              if (_activeRoutine != null) {
                await RoutineExportService.shareRoutines([_activeRoutine!]);
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Routine exported successfully')),
                  );
                }
              }
            },
          ),
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () {
              Navigator.pushNamed(context, '/routine');
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                _buildProgressBar(),
                Expanded(
                  child: _todayBlocks.isEmpty
                      ? _buildEmptyState()
                      : AnimatedTimeline(
                          blocks: _todayBlocks,
                          onBlockComplete: _toggleBlockComplete,
                        ),
                ),
              ],
            ),
    );
  }

  Widget _buildProgressBar() {
    final progress = _calculateProgress();
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Routine Progress', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              Text('${(progress * 100).toInt()}%', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 8),
          LinearProgressIndicator(
            value: progress,
            minHeight: 8,
            borderRadius: BorderRadius.circular(4),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.schedule, size: 64, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Text('No routine set for today', style: TextStyle(fontSize: 18, color: Colors.grey[600])),
          const SizedBox(height: 8),
          ElevatedButton(
            onPressed: () => Navigator.pushNamed(context, '/routine'),
            child: const Text('Create Routine'),
          ),
        ],
      ),
    );
  }
}


import 'package:flutter/material.dart';
import 'package:study_tracker_app/features/tasks/presentation/screens/task_list_screen.dart';
import 'package:study_tracker_app/features/tasks/presentation/screens/add_task_screen.dart';
import 'package:study_tracker_app/features/routines/presentation/screens/routine_builder_screen.dart';
import 'package:study_tracker_app/features/diary/presentation/screens/diary_screen.dart';
import 'package:study_tracker_app/features/alarms/presentation/screens/alarm_list_screen.dart';
import 'package:study_tracker_app/features/countdown/presentation/screens/countdown_screen.dart';
import 'package:study_tracker_app/features/app_blocker/presentation/screens/app_blocker_screen.dart';
import 'package:study_tracker_app/features/progress/presentation/screens/progress_screen.dart';
import 'package:study_tracker_app/features/rewards/presentation/screens/rewards_screen.dart';
import 'package:study_tracker_app/features/settings/presentation/screens/settings_screen.dart';

class AppRouter {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/':
        return MaterialPageRoute(builder: (_) => const HomeScreen());
      case '/tasks':
        return MaterialPageRoute(builder: (_) => const TaskListScreen());
      case '/add-task':
        return MaterialPageRoute(builder: (_) => const AddTaskScreen());
      case '/routine':
        return MaterialPageRoute(builder: (_) => const RoutineBuilderScreen());
      case '/diary':
        return MaterialPageRoute(builder: (_) => const DiaryScreen());
      case '/alarms':
        return MaterialPageRoute(builder: (_) => const AlarmListScreen());
      case '/countdown':
        return MaterialPageRoute(builder: (_) => const CountdownScreen());
      case '/app-blocker':
        return MaterialPageRoute(builder: (_) => const AppBlockerScreen());
      case '/progress':
        return MaterialPageRoute(builder: (_) => const ProgressScreen());
      case '/rewards':
        return MaterialPageRoute(builder: (_) => const RewardsScreen());
      case '/settings':
        return MaterialPageRoute(builder: (_) => const SettingsScreen());
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(child: Text('No route defined for ${settings.name}')),
          ),
        );
    }
  }
}

// Placeholder for HomeScreen - will be implemented
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) => const Scaffold(body: Center(child: Text('Home')));
}


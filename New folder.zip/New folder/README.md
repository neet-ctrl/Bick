# Study Tracker App

A comprehensive Flutter application for tracking study, tasks, routines, and productivity with advanced features like alarm missions, app blocking, and progress tracking.

## Features

### ✅ Task & Study Tracking
- Subtasks inside each task
- Estimated and actual time tracking
- Overdue highlighting
- History log
- Repeat tasks (daily, weekly, monthly, custom)
- Urgent category with badges
- Pinned tasks
- Color-coded subjects
- Focus timer (25 min, 45 min, custom)

### ✅ Routine & Day Planning
- Morning and Night routine builders
- Drag & Drop routine blocks
- Auto-shift routine
- Break manager
- Routine progress bar
- Multiple routine profiles
- Block time slots

### ✅ Diary & Notes
- Daily diary with timestamps
- Photo attachments
- Daily summary
- Mood selection
- Search functionality
- PIN lock
- PDF export

### ✅ Alarm System
- Math missions
- Memory/Maze puzzles
- Shake-to-stop
- Step counter mission
- QR Code mission
- Loud mode
- Repeat alarms
- Interval alarms
- Skip reason tracking
- Oversleep detection

### ✅ Countdown & Deadlines
- Subject-wise countdown
- Task-specific countdown
- Daily goal countdown
- Long-term countdown
- Animated progress ring
- Pause/Resume

### ✅ App Blocker & Focus System
- App usage tracking
- Study mode
- Strict mode with puzzles
- Whitelist mode
- App time limits
- Focus overlay
- Scheduled blocking
- Emergency escape

### ✅ Reason & Promise System
- Reason templates
- Promise types
- Promise tracking
- Weekly reports
- Bounce-back tasks

### ✅ Progress Tracking
- Calendar view
- Consistency streaks
- Study hours graph
- Subject time graph
- Completed tasks count
- Missed tasks graph
- Routine follow percentage

### ✅ Motivation & Rewards
- Points system
- Theme unlocking
- Daily challenges
- Badge system
- Custom motivational messages

### ✅ Security & Backup
- App lock with PIN/Fingerprint
- Diary lock
- Encrypted storage
- Backup to JSON
- Restore from backup

## Installation

1. Clone the repository
2. Run `flutter pub get`
3. Run `flutter run`

## Building APK

```bash
flutter build apk --release
```

## Permissions

The app requires the following Android permissions:
- SCHEDULE_EXACT_ALARM
- POST_NOTIFICATIONS
- PACKAGE_USAGE_STATS
- ACTIVITY_RECOGNITION
- CAMERA
- And more (see AndroidManifest.xml)

## Notes

- Some features require additional Android system permissions that need to be granted manually
- App blocking features require usage stats permission
- Alarm missions require sensor permissions
- QR code scanning requires camera permission

## License

This project is created for educational purposes.


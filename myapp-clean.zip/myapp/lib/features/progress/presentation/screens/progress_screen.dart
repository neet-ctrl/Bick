import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';

class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});

  @override
  State<ProgressScreen> createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen> {
  DateTime _selectedDay = DateTime.now();
  DateTime _focusedDay = DateTime.now();
  Map<DateTime, int> _studyDays = {};

  @override
  void initState() {
    super.initState();
    _loadStudyData();
  }

  Future<void> _loadStudyData() async {
    final tasks = await DatabaseHelper.instance.getTasks();
    final studyMap = <DateTime, int>{};
    
    for (var task in tasks) {
      if (task.isCompleted && task.actualMinutes != null) {
        final date = DateTime(task.completedAt!.year, task.completedAt!.month, task.completedAt!.day);
        studyMap[date] = (studyMap[date] ?? 0) + (task.actualMinutes ?? 0);
      }
    }
    
    setState(() => _studyDays = studyMap);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Progress'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildCalendar(),
          const SizedBox(height: 24),
          _buildStreakCard(),
          const SizedBox(height: 24),
          _buildStudyHoursChart(),
          const SizedBox(height: 24),
          _buildTasksCompletedChart(),
        ],
      ),
    );
  }

  Widget _buildCalendar() {
    return Card(
      child: TableCalendar(
        firstDay: DateTime.utc(2020, 1, 1),
        lastDay: DateTime.utc(2030, 12, 31),
        focusedDay: _focusedDay,
        selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
        onDaySelected: (selectedDay, focusedDay) {
          setState(() {
            _selectedDay = selectedDay;
            _focusedDay = focusedDay;
          });
        },
        calendarStyle: CalendarStyle(
          todayDecoration: BoxDecoration(
            color: Colors.blue.withOpacity(0.5),
            shape: BoxShape.circle,
          ),
          selectedDecoration: const BoxDecoration(
            color: Colors.blue,
            shape: BoxShape.circle,
          ),
          markerDecoration: const BoxDecoration(
            color: Colors.green,
            shape: BoxShape.circle,
          ),
        ),
        calendarBuilders: CalendarBuilders(
          markerBuilder: (context, day, events) {
            if (events.isNotEmpty) {
              return Positioned(
                right: 1,
                bottom: 1,
                child: Container(
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.green,
                  ),
                  width: 6,
                  height: 6,
                ),
              );
            }
            return null;
          },
        ),
      ),
    );
  }

  Widget _buildStreakCard() {
    int currentStreak = 0;
    int longestStreak = 0;
    
    // Calculate streaks from study days
    final sortedDays = _studyDays.keys.toList()..sort();
    if (sortedDays.isNotEmpty) {
      int tempStreak = 1;
      for (int i = 1; i < sortedDays.length; i++) {
        final diff = sortedDays[i].difference(sortedDays[i - 1]).inDays;
        if (diff == 1) {
          tempStreak++;
        } else {
          longestStreak = tempStreak > longestStreak ? tempStreak : longestStreak;
          tempStreak = 1;
        }
      }
      longestStreak = tempStreak > longestStreak ? tempStreak : longestStreak;
      currentStreak = tempStreak;
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildStatItem('Current Streak', '$currentStreak days', Icons.local_fire_department),
            _buildStatItem('Longest Streak', '$longestStreak days', Icons.emoji_events),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon) {
    return Column(
      children: [
        Icon(icon, size: 32),
        const SizedBox(height: 8),
        Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        Text(label, style: TextStyle(color: Colors.grey[600])),
      ],
    );
  }

  Widget _buildStudyHoursChart() {
    // Weekly study hours data
    final weeklyData = List.generate(7, (index) {
      final day = DateTime.now().subtract(Duration(days: 6 - index));
      final date = DateTime(day.year, day.month, day.day);
      return _studyDays[date] ?? 0;
    });

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Weekly Study Hours', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            SizedBox(
              height: 200,
              child: BarChart(
                BarChartData(
                  barGroups: weeklyData.asMap().entries.map((entry) {
                    return BarChartGroupData(
                      x: entry.key,
                      barRods: [
                        BarChartRodData(
                          toY: entry.value / 60.0, // Convert minutes to hours
                          color: Colors.blue,
                          width: 20,
                          backDrawRodData: BackgroundBarChartRodData(
                            show: true,
                            toY: 8,
                            color: Colors.grey[200],
                          ),
                        ),
                      ],
                    );
                  }).toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTasksCompletedChart() {
    final tasks = _studyDays.values.length;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Tasks Completed', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Text('$tasks tasks completed this month', style: const TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}

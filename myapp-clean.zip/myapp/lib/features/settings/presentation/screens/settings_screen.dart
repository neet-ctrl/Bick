import 'package:flutter/material.dart';
import 'package:study_tracker_app/core/services/backup_service.dart';
import 'package:study_tracker_app/core/services/security_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _appLockEnabled = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final enabled = await SecurityService.instance.isAppLockEnabled();
    setState(() => _appLockEnabled = enabled);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSecuritySection(),
          const SizedBox(height: 24),
          _buildBackupSection(),
          const SizedBox(height: 24),
          _buildAboutSection(),
        ],
      ),
    );
  }

  Widget _buildSecuritySection() {
    return Card(
      child: Column(
        children: [
          SwitchListTile(
            title: const Text('App Lock'),
            subtitle: const Text('Lock app with PIN/Fingerprint'),
            value: _appLockEnabled,
            onChanged: (value) async {
              await SecurityService.instance.setAppLock(value);
              setState(() => _appLockEnabled = value);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildBackupSection() {
    return Card(
      child: Column(
        children: [
          ListTile(
            title: const Text('Backup Data'),
            subtitle: const Text('Export your data to JSON'),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () async {
              await BackupService.instance.shareBackup();
            },
          ),
          const Divider(),
          ListTile(
            title: const Text('Restore Data'),
            subtitle: const Text('Import data from backup'),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              // Show file picker and restore
            },
          ),
        ],
      ),
    );
  }

  Widget _buildAboutSection() {
    return const Card(
      child: Column(
        children: [
          ListTile(
            title: Text('Version'),
            trailing: Text('1.0.0'),
          ),
          Divider(),
          ListTile(
            title: Text('About'),
            subtitle: Text('Study Tracker App'),
            trailing: Icon(Icons.info),
          ),
        ],
      ),
    );
  }
}


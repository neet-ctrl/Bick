import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:study_tracker_app/core/database/models.dart';

class TaskExportService {
  static Future<File> exportTasks(List<Task> tasks, {DateTime? startDate, DateTime? endDate}) async {
    final filteredTasks = tasks.where((task) {
      if (startDate != null && task.dueDate != null && task.dueDate!.isBefore(startDate)) {
        return false;
      }
      if (endDate != null && task.dueDate != null && task.dueDate!.isAfter(endDate)) {
        return false;
      }
      return true;
    }).toList();

    final exportData = {
      'exportDate': DateTime.now().toIso8601String(),
      'totalTasks': filteredTasks.length,
      'tasks': filteredTasks.map((task) => task.toJson()).toList(),
    };

    final jsonString = jsonEncode(exportData);
    final directory = await getTemporaryDirectory();
    final file = File('${directory.path}/tasks_export_${DateTime.now().millisecondsSinceEpoch}.json');
    await file.writeAsString(jsonString);
    
    return file;
  }

  static Future<void> shareTasks(List<Task> tasks, {DateTime? startDate, DateTime? endDate}) async {
    final file = await exportTasks(tasks, startDate: startDate, endDate: endDate);
    await Share.shareXFiles([XFile(file.path)], text: 'Tasks Export');
  }
}


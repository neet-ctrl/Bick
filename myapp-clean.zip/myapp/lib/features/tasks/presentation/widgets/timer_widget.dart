import 'dart:async';
import 'package:flutter/material.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';

class TimerWidget extends StatefulWidget {
  final Task task;

  const TimerWidget({super.key, required this.task});

  @override
  State<TimerWidget> createState() => _TimerWidgetState();
}

class _TimerWidgetState extends State<TimerWidget> {
  Timer? _timer;
  int _elapsedSeconds = 0;
  bool _isRunning = false;
  late Task _task;

  @override
  void initState() {
    super.initState();
    _task = widget.task;
  }

  void _startTimer() {
    _isRunning = true;
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _elapsedSeconds++;
      });
    });
  }

  void _stopTimer() {
    _isRunning = false;
    _timer?.cancel();
  }

  void _resetTimer() {
    _stopTimer();
    setState(() {
      _elapsedSeconds = 0;
    });
  }

  Future<void> _saveTime() async {
    _stopTimer();
    _task.actualMinutes = (_elapsedSeconds / 60).round();
    await DatabaseHelper.instance.updateTask(_task);
    
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Saved ${_task.actualMinutes} minutes')),
      );
    }
  }

  String _formatTime(int seconds) {
    final hours = seconds ~/ 3600;
    final minutes = (seconds % 3600) ~/ 60;
    final secs = seconds % 60;
    
    if (hours > 0) {
      return '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
    }
    return '${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          _formatTime(_elapsedSeconds),
          style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (!_isRunning)
              ElevatedButton.icon(
                onPressed: _startTimer,
                icon: const Icon(Icons.play_arrow),
                label: const Text('Start'),
              )
            else
              ElevatedButton.icon(
                onPressed: _stopTimer,
                icon: const Icon(Icons.pause),
                label: const Text('Pause'),
              ),
            const SizedBox(width: 16),
            ElevatedButton.icon(
              onPressed: _resetTimer,
              icon: const Icon(Icons.refresh),
              label: const Text('Reset'),
            ),
            const SizedBox(width: 16),
            ElevatedButton.icon(
              onPressed: _elapsedSeconds > 0 ? _saveTime : null,
              icon: const Icon(Icons.save),
              label: const Text('Save'),
            ),
          ],
        ),
        if (_task.estimatedMinutes > 0) ...[
          const SizedBox(height: 16),
          LinearProgressIndicator(
            value: (_elapsedSeconds / 60 / _task.estimatedMinutes).clamp(0.0, 1.0),
          ),
          const SizedBox(height: 8),
          Text(
            '${(_elapsedSeconds / 60).round()} / ${_task.estimatedMinutes} minutes',
            style: TextStyle(color: Colors.grey[600]),
          ),
        ],
      ],
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}


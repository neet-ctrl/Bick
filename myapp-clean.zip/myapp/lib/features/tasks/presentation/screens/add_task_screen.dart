import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';
import 'package:study_tracker_app/core/constants/app_constants.dart';

class AddTaskScreen extends StatefulWidget {
  final Task? task;

  const AddTaskScreen({super.key, this.task});

  @override
  State<AddTaskScreen> createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _estimatedTimeController = TextEditingController();
  
  String _selectedCategory = 'Study';
  String? _selectedSubject;
  String _selectedColor = '#2196F3';
  DateTime? _dueDate;
  bool _isUrgent = false;
  bool _isPinned = false;
  RepeatType? _repeatType;
  int _focusTimerMinutes = 25;
  List<Subtask> _subtasks = [];
  String? _attachmentPath;

  @override
  void initState() {
    super.initState();
    if (widget.task != null) {
      _loadTaskData();
    }
  }

  void _loadTaskData() {
    final task = widget.task!;
    _titleController.text = task.title;
    _descriptionController.text = task.description ?? '';
    _estimatedTimeController.text = task.estimatedMinutes.toString();
    _selectedCategory = task.category;
    _selectedSubject = task.subject;
    _selectedColor = task.colorCode;
    _dueDate = task.dueDate;
    _isUrgent = task.isUrgent;
    _isPinned = task.isPinned;
    _repeatType = task.repeatType;
    _focusTimerMinutes = task.focusTimerMinutes;
    _subtasks = List.from(task.subtasks);
    // _attachmentPath = task.attachmentPath; // Assuming you add this to your Task model
  }

  Future<void> _showImageSourceDialog() async {
    final source = await showDialog<ImageSource>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Select Image Source'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, ImageSource.camera),
            child: const Text('Camera'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, ImageSource.gallery),
            child: const Text('Gallery'),
          ),
        ],
      ),
    );

    if (source != null) {
      final picker = ImagePicker();
      final pickedFile = await picker.pickImage(source: source);
      if (pickedFile != null) {
        setState(() => _attachmentPath = pickedFile.path);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.task == null ? 'Add Task' : 'Edit Task'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveTask,
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Task Title *',
                border: OutlineInputBorder(),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter a task title';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _descriptionController,
              decoration: const InputDecoration(
                labelText: 'Description',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              initialValue: _selectedCategory,
              decoration: const InputDecoration(
                labelText: 'Category',
                border: OutlineInputBorder(),
              ),
              items: AppConstants.categories.map((category) {
                return DropdownMenuItem(value: category, child: Text(category));
              }).toList(),
              onChanged: (value) => setState(() => _selectedCategory = value!),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              initialValue: _selectedSubject,
              decoration: const InputDecoration(
                labelText: 'Subject (Optional)',
                border: OutlineInputBorder(),
              ),
              items: AppConstants.subjectColors.keys.map((subject) {
                return DropdownMenuItem(value: subject, child: Text(subject));
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedSubject = value;
                  if (value != null) {
                    _selectedColor = AppConstants.subjectColors[value]!;
                  }
                });
              },
            ),
            const SizedBox(height: 16),
            InkWell(
              onTap: () => _selectDueDate(),
              child: InputDecorator(
                decoration: const InputDecoration(
                  labelText: 'Due Date',
                  border: OutlineInputBorder(),
                ),
                child: Text(_dueDate != null
                    ? '${_dueDate!.day}/${_dueDate!.month}/${_dueDate!.year}'
                    : 'Select date'),
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _estimatedTimeController,
              decoration: const InputDecoration(
                labelText: 'Estimated Time (minutes)',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<int>(
              initialValue: _focusTimerMinutes,
              decoration: const InputDecoration(
                labelText: 'Focus Timer',
                border: OutlineInputBorder(),
              ),
              items: AppConstants.focusTimerPresets.map((minutes) {
                return DropdownMenuItem(value: minutes, child: Text('$minutes minutes'));
              }).toList(),
              onChanged: (value) => setState(() => _focusTimerMinutes = value!),
            ),
            const SizedBox(height: 16),
            SwitchListTile(
              title: const Text('Urgent'),
              value: _isUrgent,
              onChanged: (value) => setState(() => _isUrgent = value),
            ),
            SwitchListTile(
              title: const Text('Pin to Top'),
              value: _isPinned,
              onChanged: (value) => setState(() => _isPinned = value),
            ),
            const SizedBox(height: 16),
            TextButton.icon(
              onPressed: _showImageSourceDialog,
              icon: const Icon(Icons.attach_file),
              label: Text(_attachmentPath ?? 'Add attachment'),
            ),
            const SizedBox(height: 16),
            const Text('Subtasks', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ..._subtasks.asMap().entries.map((entry) {
              return ListTile(
                title: Text(entry.value.title),
                trailing: IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () {
                    setState(() => _subtasks.removeAt(entry.key));
                  },
                ),
              );
            }),
            TextButton.icon(
              onPressed: _addSubtask,
              icon: const Icon(Icons.add),
              label: const Text('Add Subtask'),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _saveTask,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: const Text('Save Task'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectDueDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _dueDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (date != null) {
      setState(() => _dueDate = date);
    }
  }

  Future<void> _addSubtask() async {
    final controller = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Subtask'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: 'Subtask title'),
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, controller.text),
            child: const Text('Add'),
          ),
        ],
      ),
    );

    if (result != null && result.isNotEmpty) {
      setState(() {
        _subtasks.add(Subtask(
          id: const Uuid().v4(),
          title: result,
        ));
      });
    }
  }

  Future<void> _saveTask() async {
    if (!_formKey.currentState!.validate()) return;

    final task = Task(
      id: widget.task?.id ?? const Uuid().v4(),
      title: _titleController.text,
      description: _descriptionController.text.isEmpty ? null : _descriptionController.text,
      createdAt: widget.task?.createdAt ?? DateTime.now(),
      dueDate: _dueDate,
      estimatedMinutes: int.tryParse(_estimatedTimeController.text) ?? 0,
      isUrgent: _isUrgent,
      isPinned: _isPinned,
      colorCode: _selectedColor,
      category: _selectedCategory,
      subject: _selectedSubject,
      subtasks: _subtasks,
      repeatType: _repeatType,
      focusTimerMinutes: _focusTimerMinutes,
      // attachmentPath: _attachmentPath, // Add this to your Task model
    );

    await DatabaseHelper.instance.insertTask(task);
    
    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Task saved successfully')),
      );
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _estimatedTimeController.dispose();
    super.dispose();
  }
}

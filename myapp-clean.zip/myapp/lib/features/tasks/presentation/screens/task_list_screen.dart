import 'package:flutter/material.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/core/constants/colors.dart';
import 'package:study_tracker_app/features/tasks/presentation/widgets/task_card.dart';
import 'package:study_tracker_app/features/tasks/presentation/widgets/failure_reason_dialog.dart';
import 'package:study_tracker_app/features/tasks/presentation/widgets/particle_animation.dart';
import 'package:study_tracker_app/features/tasks/presentation/screens/add_task_screen.dart';
import 'package:study_tracker_app/features/tasks/presentation/screens/task_detail_screen.dart';
import 'package:study_tracker_app/features/tasks/services/task_notification_service.dart';
import 'package:study_tracker_app/features/tasks/services/task_export_service.dart';

class TaskListScreen extends StatefulWidget {
  const TaskListScreen({super.key});

  @override
  State<TaskListScreen> createState() => _TaskListScreenState();
}

class _TaskListScreenState extends State<TaskListScreen> {
  List<Task> _tasks = [];
  List<Task> _filteredTasks = [];
  String _selectedFilter = 'All';
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadTasks();
  }

  Future<void> _loadTasks() async {
    setState(() => _isLoading = true);
    final tasks = await DatabaseHelper.instance.getTasks();
    setState(() {
      _tasks = tasks;
      _filteredTasks = tasks;
      _isLoading = false;
    });
  }

  void _filterTasks(String filter) {
    setState(() {
      _selectedFilter = filter;
      switch (filter) {
        case 'Pending':
          _filteredTasks = _tasks.where((t) => !t.isCompleted).toList();
          break;
        case 'Completed':
          _filteredTasks = _tasks.where((t) => t.isCompleted).toList();
          break;
        case 'Urgent':
          _filteredTasks = _tasks.where((t) => t.isUrgent && !t.isCompleted).toList();
          break;
        case 'Overdue':
          _filteredTasks = _tasks.where((t) => t.isOverdue).toList();
          break;
        default:
          _filteredTasks = _tasks;
      }
      // Sort: pinned first, then by due date
      _filteredTasks.sort((a, b) {
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        if (a.dueDate == null && b.dueDate != null) return 1;
        if (a.dueDate != null && b.dueDate == null) return -1;
        if (a.dueDate != null && b.dueDate != null) {
          return a.dueDate!.compareTo(b.dueDate!);
        }
        return 0;
      });
    });
  }

  Future<void> _toggleTaskComplete(Task task) async {
    if (!task.isCompleted) {
      task.isCompleted = true;
      task.completedAt = DateTime.now();
      await DatabaseHelper.instance.updateTask(task);
      
      // Show particle animation
      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) => Dialog(
            backgroundColor: Colors.transparent,
            child: ParticleAnimation(
              onComplete: () => Navigator.pop(context),
            ),
          ),
        );
      }
      
      // Cancel notification if exists
      await TaskNotificationService.instance.cancelTaskReminder(task.id);
    } else {
      task.isCompleted = false;
      task.completedAt = null;
      await DatabaseHelper.instance.updateTask(task);
      
      // Reschedule notification
      await TaskNotificationService.instance.scheduleTaskReminder(task);
    }
    _loadTasks();
  }

  Future<void> _showFailureDialog(Task task) async {
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (context) => FailureReasonDialog(task: task),
    );
    
    if (result != null) {
      // Handle failure reason and promise
      _loadTasks();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tasks'),
        actions: [
          IconButton(
            icon: const Icon(Icons.upload_file),
            tooltip: 'Export Tasks',
            onPressed: () async {
              await TaskExportService.shareTasks(_tasks);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Tasks exported successfully')),
                );
              }
            },
          ),
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () {
              showModalBottomSheet(
                context: context,
                builder: (context) => _buildFilterSheet(),
              );
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _filteredTasks.isEmpty
              ? _buildEmptyState()
              : RefreshIndicator(
                  onRefresh: _loadTasks,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _filteredTasks.length,
                    itemBuilder: (context, index) {
                      final task = _filteredTasks[index];
                      return Dismissible(
                        key: Key(task.id),
                        direction: DismissDirection.endToStart,
                        background: Container(
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(right: 20),
                          color: task.isCompleted ? Colors.grey : AppColors.success,
                          child: const Icon(Icons.check, color: Colors.white, size: 32),
                        ),
                        onDismissed: (direction) {
                          if (!task.isCompleted) {
                            _toggleTaskComplete(task);
                          }
                        },
                        child: TaskCard(
                          task: task,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => TaskDetailScreen(task: task),
                              ),
                            ).then((_) => _loadTasks());
                          },
                          onComplete: () => _toggleTaskComplete(task),
                          onFailure: () => _showFailureDialog(task),
                        ),
                      );
                    },
                  ),
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const AddTaskScreen()),
          ).then((_) => _loadTasks());
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.task_alt, size: 64, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Text(
            'No tasks found',
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
          const SizedBox(height: 8),
          Text(
            'Tap + to add a new task',
            style: TextStyle(color: Colors.grey[500]),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterSheet() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('Filter Tasks', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          ...['All', 'Pending', 'Completed', 'Urgent', 'Overdue'].map((filter) {
            return ListTile(
              title: Text(filter),
              trailing: _selectedFilter == filter ? const Icon(Icons.check) : null,
              onTap: () {
                _filterTasks(filter);
                Navigator.pop(context);
              },
            );
          }),
        ],
      ),
    );
  }
}


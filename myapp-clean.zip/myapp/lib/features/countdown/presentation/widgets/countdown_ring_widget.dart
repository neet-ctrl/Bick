import 'dart:async';
import 'package:flutter/material.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';

class CountdownRingWidget extends StatefulWidget {
  final Countdown countdown;

  const CountdownRingWidget({super.key, required this.countdown});

  @override
  State<CountdownRingWidget> createState() => _CountdownRingWidgetState();
}

class _CountdownRingWidgetState extends State<CountdownRingWidget> {
  Timer? _timer;
  late Countdown _countdown;

  @override
  void initState() {
    super.initState();
    _countdown = widget.countdown;
    _startTimer();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) {
        setState(() {});
      }
    });
  }

  Future<void> _togglePause() async {
    if (_countdown.isPaused) {
      // Resume
      if (_countdown.pausedAt != null && _countdown.pausedDuration != null) {
        final pausedDuration = DateTime.now().difference(_countdown.pausedAt!);
        _countdown.pausedDuration = (_countdown.pausedDuration! + pausedDuration.inSeconds);
      }
      _countdown.isPaused = false;
      _countdown.pausedAt = null;
    } else {
      // Pause
      _countdown.isPaused = true;
      _countdown.pausedAt = DateTime.now();
    }
    await DatabaseHelper.instance.database.then((db) {
      db.update('countdowns', {
        'isPaused': _countdown.isPaused ? 1 : 0,
        'pausedAt': _countdown.pausedAt?.toIso8601String(),
        'pausedDuration': _countdown.pausedDuration,
      }, where: 'id = ?', whereArgs: [_countdown.id]);
    });
  }

  @override
  Widget build(BuildContext context) {
    final remaining = _countdown.remaining;
    final total = _countdown.targetDate.difference(DateTime.now().subtract(const Duration(days: 30)));
    final progress = 1.0 - (remaining.inSeconds / total.inSeconds).clamp(0.0, 1.0);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 120,
              height: 120,
              child: CircularProgressIndicator(
                value: progress,
                strokeWidth: 8,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              _countdown.title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              _formatDuration(remaining),
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            if (_countdown.subject != null) ...[
              const SizedBox(height: 8),
              Chip(label: Text(_countdown.subject!)),
            ],
            const SizedBox(height: 8),
            IconButton(
              icon: Icon(_countdown.isPaused ? Icons.play_arrow : Icons.pause),
              onPressed: _togglePause,
            ),
          ],
        ),
      ),
    );
  }

  String _formatDuration(Duration duration) {
    if (duration.isNegative) return 'Expired';
    
    final days = duration.inDays;
    final hours = duration.inHours % 24;
    final minutes = duration.inMinutes % 60;
    
    if (days > 0) {
      return '${days}d ${hours}h';
    } else if (hours > 0) {
      return '${hours}h ${minutes}m';
    } else {
      return '${minutes}m';
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}


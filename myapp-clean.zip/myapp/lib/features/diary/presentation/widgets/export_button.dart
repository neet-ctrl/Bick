import 'package:flutter/material.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/features/diary/services/pdf_export_service.dart';
import 'package:share_plus/share_plus.dart';
import 'package:intl/intl.dart';

class ExportButton extends StatelessWidget {
  final DiaryEntry entry;

  const ExportButton({super.key, required this.entry});

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      onSelected: (value) async {
        if (value == 'pdf') {
          final pdfFile = await PdfExportService.exportDiaryEntry(entry);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('PDF exported to ${pdfFile.path}')),
          );
        } else if (value == 'share') {
           final text =
                "Diary Entry - ${DateFormat('MMMM dd, yyyy').format(entry.date)}\n\n"
                "Mood: ${entry.mood ?? 'Not set'}\n\n"
                "Morning Note:\n${entry.morningNote ?? 'Empty'}\n\n"
                "Evening Note:\n${entry.eveningNote ?? 'Empty'}";
            await Share.share(text, subject: 'Diary Entry');
        }
      },
      itemBuilder: (context) => [
        const PopupMenuItem(
          value: 'pdf',
          child: Text('Export as PDF'),
        ),
        const PopupMenuItem(
          value: 'share',
          child: Text('Share'),
        ),
      ],
      icon: const Icon(Icons.share),
    );
  }
}

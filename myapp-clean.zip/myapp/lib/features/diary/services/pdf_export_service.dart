import 'dart:io';
import 'package:pdf/widgets.dart' as pw;
import 'package:study_tracker_app/core/database/models.dart';
import 'package:path_provider/path_provider.dart';
import 'package:intl/intl.dart';

class PdfExportService {
  static Future<File> exportDiaryEntry(DiaryEntry entry) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        build: (pw.Context context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('Diary Entry', style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 16),
              pw.Text('Date: ${DateFormat('MMMM dd, yyyy').format(entry.date)}'),
              pw.SizedBox(height: 8),
              pw.Text('Mood: ${entry.mood ?? 'Not set'}'),
              pw.SizedBox(height: 16),
              pw.Text('Morning Note:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
              pw.Text(entry.morningNote ?? 'Empty'),
              pw.SizedBox(height: 16),
              pw.Text('Evening Note:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
              pw.Text(entry.eveningNote ?? 'Empty'),
            ],
          );
        },
      ),
    );

    final output = await getTemporaryDirectory();
    final file = File('${output.path}/diary_entry.pdf');
    await file.writeAsBytes(await pdf.save());
    return file;
  }
}

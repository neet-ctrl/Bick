import 'dart:async';
import 'dart:math';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:pedometer/pedometer.dart';
import 'package:study_tracker_app/core/database/models.dart';

class AlarmMissionService {
  final Random _random = Random();
  StreamSubscription<AccelerometerEvent>? _shakeSubscription;
  StreamSubscription<StepCount>? _stepSubscription;
  int _shakeCount = 0;
  int _stepCount = 0;
  int _requiredShakes = 0;
  int _requiredSteps = 0;

  Future<bool> completeMission({
    required AlarmMissionType missionType,
    required int difficulty,
    required StudyAlarm alarm,
  }) async {
    switch (missionType) {
      case AlarmMissionType.math:
        return _solveMathPuzzle(difficulty);
      case AlarmMissionType.memory:
        return _solveMemoryPuzzle(difficulty);
      case AlarmMissionType.maze:
        return _solveMazePuzzle(difficulty);
      case AlarmMissionType.shake:
        return await _completeShakeMission(difficulty);
      case AlarmMissionType.steps:
        return await _completeStepMission(difficulty);
      case AlarmMissionType.qrCode:
        return _verifyQRCode(alarm.qrCodeData ?? '');
      case AlarmMissionType.colorTiles:
        return _solveColorTilesPuzzle(difficulty);
      case AlarmMissionType.typing:
        return _solveTypingPuzzle(difficulty);
    }
  }

  bool _solveMathPuzzle(int difficulty) {
    for (int i = 0; i < difficulty; i++) {
      final a = _random.nextInt(100) + 1;
      final b = _random.nextInt(100) + 1;
      final op = _random.nextInt(2); // 0 = +, 1 = -
      final answer = op == 0 ? a + b : a - b;
    }
    return true; // Placeholder
  }

  bool _solveMemoryPuzzle(int difficulty) {
    final sequence = List.generate(difficulty, (_) => _random.nextInt(9) + 1);
    return true; // Placeholder
  }

  bool _solveMazePuzzle(int difficulty) {
    return true; // Placeholder
  }
   bool _solveColorTilesPuzzle(int difficulty) {
    return true; // Placeholder
  }

  bool _solveTypingPuzzle(int difficulty) {
    return true;
  }


  Future<bool> _completeShakeMission(int requiredShakes) async {
    _shakeCount = 0;
    _requiredShakes = requiredShakes;
    
    _shakeSubscription = accelerometerEvents.listen((event) {
      final magnitude = sqrt(event.x * event.x + event.y * event.y + event.z * event.z);
      if (magnitude > 15) {
        _shakeCount++;
      }
    });
    
    while (_shakeCount < _requiredShakes) {
      await Future.delayed(const Duration(milliseconds: 100));
    }
    
    _shakeSubscription?.cancel();
    return _shakeCount >= _requiredShakes;
  }

  Future<bool> _completeStepMission(int requiredSteps) async {
    _stepCount = 0;
    _requiredSteps = requiredSteps;
    int initialSteps = 0;
    
    try {
      final stepStream = Pedometer.stepCountStream;
      _stepSubscription = stepStream.listen((stepCount) {
        if (initialSteps == 0) {
          initialSteps = stepCount.steps;
        }
        _stepCount = stepCount.steps - initialSteps;
      });
      
      while (_stepCount < _requiredSteps) {
        await Future.delayed(const Duration(seconds: 1));
      }
      
      _stepSubscription?.cancel();
      return _stepCount >= _requiredSteps;
    } catch (e) {
      return false;
    }
  }

  bool _verifyQRCode(String expectedCode) {
    return true; // Placeholder
  }

  String generateMathProblem(int difficulty) {
    final a = _random.nextInt(100) + 1;
    final b = _random.nextInt(100) + 1;
    final op = _random.nextInt(2);
    final answer = op == 0 ? a + b : a - b;
    final operator = op == 0 ? '+' : '-';
    return '$a $operator $b = ?';
  }

  List<int> generateMemorySequence(int length) {
    return List.generate(length, (_) => _random.nextInt(9) + 1);
  }

  void dispose() {
    _shakeSubscription?.cancel();
    _stepSubscription?.cancel();
  }
}

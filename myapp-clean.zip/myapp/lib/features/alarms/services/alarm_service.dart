import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'package:vibration/vibration.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/shared/services/notification_service.dart';
import 'package:study_tracker_app/features/alarms/presentation/screens/alarm_mission_screen.dart';
import 'package:flutter/material.dart';
import 'alarm_mission_service.dart';

class AlarmService extends ChangeNotifier {
  static final AlarmService instance = AlarmService._init();
  final AudioPlayer _audioPlayer = AudioPlayer();
  final AlarmMissionService _missionService = AlarmMissionService();
  
  StudyAlarm? _activeAlarm;
  bool _isRinging = false;
  Timer? _oversleepTimer;

  AlarmService._init();

  StudyAlarm? get activeAlarm => _activeAlarm;
  bool get isRinging => _isRinging;

  Future<void> initialize() async {
    await _checkScheduledAlarms();
  }

  Future<void> _checkScheduledAlarms() async {
    final alarms = await DatabaseHelper.instance.getAlarms();
    final now = DateTime.now();
    
    for (var alarm in alarms) {
      if (alarm.time.isBefore(now) || alarm.time.isAtSameMomentAs(now)) {
        await triggerAlarm(alarm);
      }
    }
  }

  Future<void> scheduleAlarm(StudyAlarm alarm) async {
    await DatabaseHelper.instance.insertAlarm(alarm);
    await NotificationService.instance.scheduleNotification(
      id: alarm.id.hashCode,
      title: alarm.title,
      body: 'Time to study!',
      scheduledDate: alarm.time,
    );
    notifyListeners();
  }

  Future<void> triggerAlarm(StudyAlarm alarm, {BuildContext? context}) async {
    _activeAlarm = alarm;
    _isRinging = true;
    
    await WakelockPlus.enable();
    await Vibration.vibrate(duration: 1000);
    
    // Use custom volume level or loud mode
    if (alarm.isLoudMode) {
      await _audioPlayer.setVolume(1.0);
    } else {
      await _audioPlayer.setVolume(alarm.volumeLevel);
    }
    
    // Use custom ringtone if available
    if (alarm.ringtonePath != null && alarm.ringtonePath!.isNotEmpty) {
      await _audioPlayer.play(DeviceFileSource(alarm.ringtonePath!));
    } else {
      await _audioPlayer.play(AssetSource('sounds/alarm.mp3'));
    }
    
    await _audioPlayer.setReleaseMode(ReleaseMode.loop);
    
    // Show alarm mission screen - blocks dismissal until mission complete
    if (context != null) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => AlarmMissionScreen(alarm: alarm),
          fullscreenDialog: true,
        ),
      );
    }
    
    // Oversleep detection
    _oversleepTimer = Timer(const Duration(minutes: 5), () {
      if (_isRinging) {
        _triggerOversleepAlarm();
      }
    });
    
    notifyListeners();
  }

  Future<void> _triggerOversleepAlarm() async {
    await Vibration.vibrate(pattern: [0, 1000, 500, 1000], repeat: 3);
    await NotificationService.instance.scheduleNotification(
      id: -1,
      title: 'Oversleep Alert!',
      body: 'You haven\'t dismissed your alarm!',
      scheduledDate: DateTime.now().add(const Duration(seconds: 1)),
    );
  }

  Future<bool> dismissAlarm(AlarmMissionType missionType) async {
    if (_activeAlarm == null) return false;
    
    final success = await _missionService.completeMission(
      missionType: missionType,
      difficulty: _activeAlarm!.missionDifficulty,
      alarm: _activeAlarm!,
    );
    
    if (success) {
      await stopAlarm();
      return true;
    }
    
    return false;
  }

  Future<void> skipAlarm(String reason) async {
    if (_activeAlarm == null) return;
    
    // Save skip reason
    await stopAlarm();
  }

  Future<void> stopAlarm() async {
    _isRinging = false;
    _oversleepTimer?.cancel();
    await _audioPlayer.stop();
    await WakelockPlus.disable();
    _activeAlarm = null;
    notifyListeners();
  }

  Future<void> cancelAlarm(String alarmId) async {
    await DatabaseHelper.instance.database.then((db) {
      db.update('alarms', {'isActive': 0}, where: 'id = ?', whereArgs: [alarmId]);
    });
    await NotificationService.instance.cancelNotification(alarmId.hashCode);
    notifyListeners();
  }
}

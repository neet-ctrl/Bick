import 'dart:math';
import 'package:flutter/material.dart';

class TypingWidget extends StatefulWidget {
  final int difficulty;
  final VoidCallback onComplete;

  const TypingWidget({
    super.key,
    required this.difficulty,
    required this.onComplete,
  });

  @override
  State<TypingWidget> createState() => _TypingWidgetState();
}

class _TypingWidgetState extends State<TypingWidget> {
  final Random _random = Random();
  final TextEditingController _typingController = TextEditingController();
  final List<String> _words = [
    'STUDY', 'FOCUS', 'LEARN', 'SUCCESS', 'DEDICATE',
    'ACHIEVE', 'EFFORT', 'KNOWLEDGE', 'DISCIPLINE', 'PERSISTENCE',
    'MOTIVATION', 'EXCELLENCE', 'HARDWORK', 'DETERMINATION', 'AMBITION'
  ];
  String _targetWord = '';
  int _currentLevel = 0;
  int _correctChars = 0;

  @override
  void initState() {
    super.initState();
    _generateWord();
  }

  void _generateWord() {
    _targetWord = _words[_random.nextInt(_words.length)];
    _typingController.clear();
    _correctChars = 0;
  }

  void _checkTyping(String value) {
    if (value.length <= _targetWord.length) {
      setState(() {
        _correctChars = 0;
        for (int i = 0; i < value.length && i < _targetWord.length; i++) {
          if (value[i].toUpperCase() == _targetWord[i]) {
            _correctChars++;
          } else {
            break;
          }
        }
      });
    }

    if (value.toUpperCase() == _targetWord) {
      setState(() {
        _currentLevel++;
      });
      
      if (_currentLevel >= widget.difficulty) {
        widget.onComplete();
      } else {
        _generateWord();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Typing Challenge ${_currentLevel + 1}/${widget.difficulty}',
            style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 48),
          Container(
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                Text(
                  _targetWord,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 48,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 4,
                  ),
                ),
                const SizedBox(height: 32),
                SizedBox(
                  width: 300,
                  child: TextField(
                    controller: _typingController,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      letterSpacing: 4,
                    ),
                    decoration: InputDecoration(
                      hintText: 'Type here...',
                      hintStyle: TextStyle(color: Colors.white.withOpacity(0.5)),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: Colors.white),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: Colors.white),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: Colors.green, width: 2),
                      ),
                    ),
                    onChanged: _checkTyping,
                    autofocus: true,
                    textCapitalization: TextCapitalization.characters,
                  ),
                ),
                const SizedBox(height: 16),
                LinearProgressIndicator(
                  value: _correctChars / _targetWord.length,
                  backgroundColor: Colors.grey[800],
                  valueColor: const AlwaysStoppedAnimation<Color>(Colors.green),
                ),
                const SizedBox(height: 8),
                Text(
                  '$_correctChars/${_targetWord.length} correct',
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _typingController.dispose();
    super.dispose();
  }
}


import 'dart:math';
import 'package:flutter/material.dart';

class ColorTilesWidget extends StatefulWidget {
  final int difficulty;
  final VoidCallback onComplete;

  const ColorTilesWidget({
    super.key,
    required this.difficulty,
    required this.onComplete,
  });

  @override
  State<ColorTilesWidget> createState() => _ColorTilesWidgetState();
}

class _ColorTilesWidgetState extends State<ColorTilesWidget> {
  final Random _random = Random();
  final List<Color> _colors = [
    Colors.red,
    Colors.blue,
    Colors.green,
    Colors.yellow,
    Colors.orange,
    Colors.purple,
    Colors.pink,
    Colors.teal,
  ];
  Color? _targetColor;
  int _currentLevel = 0;
  List<Color> _shuffledColors = [];
  bool _showingTarget = true;

  @override
  void initState() {
    super.initState();
    _startLevel();
  }

  void _startLevel() {
    _targetColor = _colors[_random.nextInt(_colors.length)];
    _shuffledColors = List.from(_colors)..shuffle();
    _showingTarget = true;
    
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() => _showingTarget = false);
      }
    });
  }

  void _onColorTap(Color color) {
    if (_showingTarget) return;
    
    if (color == _targetColor) {
      setState(() {
        _currentLevel++;
      });
      
      if (_currentLevel >= widget.difficulty) {
        widget.onComplete();
      } else {
        _startLevel();
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Wrong color! Try again.'),
          backgroundColor: Colors.red,
        ),
      );
      _startLevel();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Find Color ${_currentLevel + 1}/${widget.difficulty}',
            style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 32),
          if (_showingTarget)
            Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                color: _targetColor,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white, width: 4),
              ),
              child: Center(
                child: Text(
                  'Remember this color!',
                  style: TextStyle(
                    color: _targetColor == Colors.yellow ? Colors.black : Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            )
          else
            Column(
              children: [
                const Text(
                  'Find the target color:',
                  style: TextStyle(color: Colors.white, fontSize: 18),
                ),
                const SizedBox(height: 24),
                GridView.builder(
                  shrinkWrap: true,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  itemCount: _shuffledColors.length,
                  itemBuilder: (context, index) {
                    final color = _shuffledColors[index];
                    return GestureDetector(
                      onTap: () => _onColorTap(color),
                      child: Container(
                        decoration: BoxDecoration(
                          color: color,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
        ],
      ),
    );
  }
}


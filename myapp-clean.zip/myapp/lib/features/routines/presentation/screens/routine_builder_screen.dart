import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/core/database/database_helper.dart';

class RoutineBuilderScreen extends StatefulWidget {
  const RoutineBuilderScreen({super.key});

  @override
  State<RoutineBuilderScreen> createState() => _RoutineBuilderScreenState();
}

class _RoutineBuilderScreenState extends State<RoutineBuilderScreen> {
  final _nameController = TextEditingController();
  String _selectedProfile = 'School Days';
  final List<RoutineBlock> _blocks = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Routine Builder'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveRoutine,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _nameController,
            decoration: const InputDecoration(
              labelText: 'Routine Name',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            initialValue: _selectedProfile,
            decoration: const InputDecoration(
              labelText: 'Profile Type',
              border: OutlineInputBorder(),
            ),
            items: ['School Days', 'Exam Days', 'Weekend'].map((profile) {
              return DropdownMenuItem(value: profile, child: Text(profile));
            }).toList(),
            onChanged: (value) => setState(() => _selectedProfile = value!),
          ),
          const SizedBox(height: 24),
          const Text('Routine Blocks', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          ..._blocks.map((block) => _buildBlockCard(block)),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: _addBlock,
            icon: const Icon(Icons.add),
            label: const Text('Add Block'),
          ),
        ],
      ),
    );
  }

  Widget _buildBlockCard(RoutineBlock block) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        title: Text(block.title),
        subtitle: Text('${block.startTime.format(context)} - ${block.durationMinutes} min'),
        trailing: IconButton(
          icon: const Icon(Icons.delete),
          onPressed: () {
            setState(() => _blocks.remove(block));
          },
        ),
        onTap: () => _editBlock(block),
      ),
    );
  }

  Future<void> _addBlock() async {
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (context) => _BlockDialog(),
    );

    if (result != null) {
      setState(() {
        _blocks.add(RoutineBlock(
          id: const Uuid().v4(),
          title: result['title'],
          startHour: result['hour'],
          startMinute: result['minute'],
          durationMinutes: result['duration'],
          type: result['type'],
          isBlocked: result['isBlocked'] ?? false,
        ));
      });
      _blocks.sort((a, b) {
        final aMinutes = a.startHour * 60 + a.startMinute;
        final bMinutes = b.startHour * 60 + b.startMinute;
        return aMinutes.compareTo(bMinutes);
      });
    }
  }

  Future<void> _editBlock(RoutineBlock block) async {
    // Similar to _addBlock but with existing values
  }

  Future<void> _saveRoutine() async {
    if (_nameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a routine name')),
      );
      return;
    }

    final routine = Routine(
      id: const Uuid().v4(),
      name: _nameController.text,
      profileType: _selectedProfile,
      blocks: _blocks,
      isActive: true,
      createdAt: DateTime.now(),
    );

    await DatabaseHelper.instance.insertRoutine(routine);
    
    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Routine saved')),
      );
    }
  }
}

class _BlockDialog extends StatefulWidget {
  @override
  State<_BlockDialog> createState() => _BlockDialogState();
}

class _BlockDialogState extends State<_BlockDialog> {
  final _titleController = TextEditingController();
  TimeOfDay _selectedTime = TimeOfDay.now();
  int _duration = 30;
  String _type = 'study';
  bool _isBlocked = false;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        padding: const EdgeInsets.all(24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _titleController,
                decoration: const InputDecoration(labelText: 'Block Title'),
              ),
              const SizedBox(height: 16),
              ListTile(
                title: const Text('Start Time'),
                trailing: Text(_selectedTime.format(context)),
                onTap: () async {
                  final time = await showTimePicker(
                    context: context,
                    initialTime: _selectedTime,
                  );
                  if (time != null) setState(() => _selectedTime = time);
                },
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<int>(
                initialValue: _duration,
                decoration: const InputDecoration(labelText: 'Duration (minutes)'),
                items: [15, 30, 45, 60, 90, 120].map((d) {
                  return DropdownMenuItem(value: d, child: Text('$d min'));
                }).toList(),
                onChanged: (value) => setState(() => _duration = value!),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                initialValue: _type,
                decoration: const InputDecoration(labelText: 'Type'),
                items: ['study', 'break', 'exercise', 'meal', 'other'].map((t) {
                  return DropdownMenuItem(value: t, child: Text(t));
                }).toList(),
                onChanged: (value) => setState(() => _type = value!),
              ),
              SwitchListTile(
                title: const Text('Blocked Time Slot'),
                value: _isBlocked,
                onChanged: (value) => setState(() => _isBlocked = value),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context, {
                        'title': _titleController.text,
                        'hour': _selectedTime.hour,
                        'minute': _selectedTime.minute,
                        'duration': _duration,
                        'type': _type,
                        'isBlocked': _isBlocked,
                      });
                    },
                    child: const Text('Add'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}


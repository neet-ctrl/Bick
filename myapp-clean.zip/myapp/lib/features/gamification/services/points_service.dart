import 'package:study_tracker_app/core/database/database_helper.dart';
import 'package:study_tracker_app/core/database/models.dart';
import 'package:study_tracker_app/core/services/notification_service.dart';

class PointsService {
  static const int pointsForTask = 10;
  static const int pointsForRoutine = 50;
  static const int pointsForStreak = 25;

  static Future<void> onTaskCompleted(Task task) async {
    final db = await DatabaseHelper.instance.database;
    final points = await db.query('user_points');
    final currentPoints = points.isNotEmpty ? UserPoints.fromJson(points.first) : UserPoints();

    currentPoints.totalPoints += pointsForTask;
    _checkBadges(currentPoints);
    await db.insert('user_points', currentPoints.toJson(), conflictAlgorithm: 'replace');
  }

  static Future<void> onRoutineCompleted(Routine routine) async {
    final db = await DatabaseHelper.instance.database;
    final points = await db.query('user_points');
    final currentPoints = points.isNotEmpty ? UserPoints.fromJson(points.first) : UserPoints();

    currentPoints.totalPoints += pointsForRoutine;
    _checkBadges(currentPoints);
    await db.insert('user_points', currentPoints.toJson(), conflictAlgorithm: 'replace');
  }

  static Future<void> onStreakMaintained() async {
    final db = await DatabaseHelper.instance.database;
    final points = await db.query('user_points');
    final currentPoints = points.isNotEmpty ? UserPoints.fromJson(points.first) : UserPoints();

    currentPoints.currentStreak++;
    if (currentPoints.currentStreak > currentPoints.longestStreak) {
      currentPoints.longestStreak = currentPoints.currentStreak;
    }
    currentPoints.totalPoints += pointsForStreak;
    
    await db.insert('user_points', currentPoints.toJson(), conflictAlgorithm: 'replace');
    NotificationService.showNotification(
      id: 200,
      title: 'Streak Maintained!',
      body: 'You have maintained a ${currentPoints.currentStreak}-day streak! Keep it up!',
    );
  }

  static void _checkBadges(UserPoints points) {
    if (points.totalPoints >= 1000 && !points.earnedBadges.contains('master')) {
      points.earnedBadges.add('master');
      NotificationService.showNotification(
        id: 100,
        title: 'Badge Unlocked!',
        body: 'You have earned the Master badge!',
      );
    }
    if (points.longestStreak >= 30 && !points.earnedBadges.contains('legend')) {
      points.earnedBadges.add('legend');
      NotificationService.showNotification(
        id: 101,
        title: 'Badge Unlocked!',
        body: 'You have earned the Legend badge for a 30-day streak!',
      );
    }
  }
}

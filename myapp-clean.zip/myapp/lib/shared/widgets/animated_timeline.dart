import 'package:flutter/material.dart';
import 'package:study_tracker_app/core/database/models.dart';

class AnimatedTimeline extends StatelessWidget {
  final List<RoutineBlock> blocks;
  final Function(RoutineBlock)? onBlockComplete;

  const AnimatedTimeline({super.key, required this.blocks, this.onBlockComplete});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: blocks.length,
      itemBuilder: (context, index) {
        final block = blocks[index];
        final isCompleted = block.isCompleted;
        
        return _TimelineItem(
          block: block,
          isFirst: index == 0,
          isLast: index == blocks.length - 1,
          isCompleted: isCompleted,
          onComplete: onBlockComplete,
        );
      },
    );
  }
}

class _TimelineItem extends StatelessWidget {
  final RoutineBlock block;
  final bool isFirst;
  final bool isLast;
  final bool isCompleted;
  final Function(RoutineBlock)? onComplete;

  const _TimelineItem({
    required this.block,
    required this.isFirst,
    required this.isLast,
    required this.isCompleted,
    this.onComplete,
  });

  bool get blockIsCompleted => block.isCompleted;

  @override
  Widget build(BuildContext context) {
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isCompleted ? Colors.green : Colors.grey[300],
                  border: Border.all(color: Colors.white, width: 2),
                ),
                child: blockIsCompleted
                    ? const Icon(Icons.check, size: 16, color: Colors.white)
                    : null,
              ),
              if (!isLast)
                Expanded(
                  child: Container(
                    width: 2,
                    color: blockIsCompleted ? Colors.green : Colors.grey[300],
                  ),
                ),
            ],
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          block.title,
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            decoration: blockIsCompleted ? TextDecoration.lineThrough : null,
                          ),
                        ),
                        Checkbox(
                          value: blockIsCompleted,
                          onChanged: (value) {
                            if (onComplete != null) {
                              onComplete!(block);
                            }
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(Icons.access_time, size: 16, color: Colors.grey[600]),
                        const SizedBox(width: 4),
                        Text(
                          '${block.startTime.format(context)} - ${block.durationMinutes} min',
                          style: TextStyle(color: Colors.grey[600]),
                        ),
                        const SizedBox(width: 16),
                        Chip(
                          label: Text(block.type),
                          labelStyle: const TextStyle(fontSize: 10),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}


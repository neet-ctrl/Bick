import 'package:flutter/material.dart';

class Task {
  String id;
  String title;
  String? description;
  DateTime createdAt;
  DateTime? dueDate;
  DateTime? completedAt;
  int estimatedMinutes;
  int? actualMinutes;
  bool isCompleted;
  bool isPinned;
  bool isUrgent;
  String colorCode;
  String category;
  String? subject;
  List<Subtask> subtasks;
  RepeatType? repeatType;
  String? repeatCustom;
  String? iconName;
  int focusTimerMinutes;
  String? alarmId;
  String? attachmentPath;

  Task({
    required this.id,
    required this.title,
    this.description,
    required this.createdAt,
    this.dueDate,
    this.completedAt,
    this.estimatedMinutes = 0,
    this.actualMinutes,
    this.isCompleted = false,
    this.isPinned = false,
    this.isUrgent = false,
    this.colorCode = '#2196F3',
    this.category = 'Study',
    this.subject,
    this.subtasks = const [],
    this.repeatType,
    this.repeatCustom,
    this.iconName,
    this.focusTimerMinutes = 25,
    this.alarmId,
    this.attachmentPath,
  });

  bool get isOverdue {
    if (dueDate == null || isCompleted) return false;
    return DateTime.now().isAfter(dueDate!);
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'description': description,
    'createdAt': createdAt.toIso8601String(),
    'dueDate': dueDate?.toIso8601String(),
    'completedAt': completedAt?.toIso8601String(),
    'estimatedMinutes': estimatedMinutes,
    'actualMinutes': actualMinutes,
    'isCompleted': isCompleted ? 1 : 0,
    'isPinned': isPinned ? 1 : 0,
    'isUrgent': isUrgent ? 1 : 0,
    'colorCode': colorCode,
    'category': category,
    'subject': subject,
    'repeatType': repeatType?.toString(),
    'repeatCustom': repeatCustom,
    'iconName': iconName,
    'focusTimerMinutes': focusTimerMinutes,
    'alarmId': alarmId,
    'attachmentPath': attachmentPath,
  };

  factory Task.fromJson(Map<String, dynamic> json) => Task(
    id: json['id'],
    title: json['title'],
    description: json['description'],
    createdAt: DateTime.parse(json['createdAt']),
    dueDate: json['dueDate'] != null ? DateTime.parse(json['dueDate']) : null,
    completedAt: json['completedAt'] != null ? DateTime.parse(json['completedAt']) : null,
    estimatedMinutes: json['estimatedMinutes'] ?? 0,
    actualMinutes: json['actualMinutes'],
    isCompleted: json['isCompleted'] == 1,
    isPinned: json['isPinned'] == 1,
    isUrgent: json['isUrgent'] == 1,
    colorCode: json['colorCode'] ?? '#2196F3',
    category: json['category'] ?? 'Study',
    subject: json['subject'],
    repeatType: json['repeatType'] != null ? RepeatType.values.firstWhere((e) => e.toString() == json['repeatType']) : null,
    repeatCustom: json['repeatCustom'],
    iconName: json['iconName'],
    focusTimerMinutes: json['focusTimerMinutes'] ?? 25,
    alarmId: json['alarmId'],
    attachmentPath: json['attachmentPath'],
  );
}

class Subtask {
  String id;
  String title;
  bool isCompleted;

  Subtask({
    required this.id,
    required this.title,
    this.isCompleted = false,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'isCompleted': isCompleted ? 1 : 0,
  };

  factory Subtask.fromJson(Map<String, dynamic> json) => Subtask(
    id: json['id'],
    title: json['title'],
    isCompleted: json['isCompleted'] == 1,
  );
}

enum RepeatType {
  daily,
  weekly,
  monthly,
  custom,
}

class Routine {
  String id;
  String name;
  String profileType;
  List<RoutineBlock> blocks;
  bool isActive;
  DateTime createdAt;

  Routine({
    required this.id,
    required this.name,
    required this.profileType,
    this.blocks = const [],
    this.isActive = false,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'profileType': profileType,
    'blocks': blocks.map((b) => b.toJson()).toList(),
    'isActive': isActive ? 1 : 0,
    'createdAt': createdAt.toIso8601String(),
  };

  factory Routine.fromJson(Map<String, dynamic> json) => Routine(
    id: json['id'],
    name: json['name'],
    profileType: json['profileType'],
    blocks: (json['blocks'] as List?)?.map((b) => RoutineBlock.fromJson(b)).toList() ?? [],
    isActive: json['isActive'] == 1,
    createdAt: DateTime.parse(json['createdAt']),
  );
}

class RoutineBlock {
  String id;
  String title;
  int startHour;
  int startMinute;
  int durationMinutes;
  String type;
  bool isBlocked;
  bool isCompleted;

  RoutineBlock({
    required this.id,
    required this.title,
    required this.startHour,
    required this.startMinute,
    required this.durationMinutes,
    required this.type,
    this.isBlocked = false,
    this.isCompleted = false,
  });

  TimeOfDay get startTime => TimeOfDay(hour: startHour, minute: startMinute);

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'startHour': startHour,
    'startMinute': startMinute,
      'durationMinutes': durationMinutes,
      'type': type,
      'isBlocked': isBlocked ? 1 : 0,
      'isCompleted': isCompleted ? 1 : 0,
    };

  factory RoutineBlock.fromJson(Map<String, dynamic> json) => RoutineBlock(
    id: json['id'],
    title: json['title'],
    startHour: json['startHour'],
    startMinute: json['startMinute'],
        durationMinutes: json['durationMinutes'],
        type: json['type'],
        isBlocked: json['isBlocked'] == 1,
        isCompleted: json['isCompleted'] == 1,
      );
}

class DiaryEntry {
  String id;
  DateTime date;
  String? morningNote;
  String? eveningNote;
  List<String> photoPaths;
  String? mood;
  int totalStudyMinutes;
  int completedTasksCount;
  int missedTasksCount;
  bool isLocked;

  DiaryEntry({
    required this.id,
    required this.date,
    this.morningNote,
    this.eveningNote,
    this.photoPaths = const [],
    this.mood,
    this.totalStudyMinutes = 0,
    this.completedTasksCount = 0,
    this.missedTasksCount = 0,
    this.isLocked = false,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'date': date.toIso8601String(),
    'morningNote': morningNote,
    'eveningNote': eveningNote,
    'photoPaths': photoPaths,
    'mood': mood,
    'totalStudyMinutes': totalStudyMinutes,
    'completedTasksCount': completedTasksCount,
    'missedTasksCount': missedTasksCount,
    'isLocked': isLocked ? 1 : 0,
  };

  factory DiaryEntry.fromJson(Map<String, dynamic> json) => DiaryEntry(
    id: json['id'],
    date: DateTime.parse(json['date']),
    morningNote: json['morningNote'],
    eveningNote: json['eveningNote'],
    photoPaths: List<String>.from(json['photoPaths'] ?? []),
    mood: json['mood'],
    totalStudyMinutes: json['totalStudyMinutes'] ?? 0,
    completedTasksCount: json['completedTasksCount'] ?? 0,
    missedTasksCount: json['missedTasksCount'] ?? 0,
    isLocked: json['isLocked'] == 1,
  );
}

class StudyAlarm {
  String id;
  DateTime time;
  String title;
  AlarmMissionType missionType;
  int missionDifficulty;
  bool isActive;
  bool isLoudMode;
  RepeatType? repeatType;
  int? intervalMinutes;
  String? qrCodeData;
  String? ringtonePath;
  int? notificationId;
  double volumeLevel; // 0.0 to 1.0
  String? missionPayload; // Add this line

  StudyAlarm({
    required this.id,
    required this.time,
    required this.title,
    required this.missionType,
    this.missionDifficulty = 20,
    this.isActive = true,
    this.isLoudMode = false,
    this.repeatType,
    this.intervalMinutes,
    this.qrCodeData,
    this.ringtonePath,
    this.notificationId,
    this.volumeLevel = 0.8,
    this.missionPayload, // Add this line
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'time': time.toIso8601String(),
    'title': title,
    'missionType': missionType.toString(),
    'missionDifficulty': missionDifficulty,
    'isActive': isActive ? 1 : 0,
    'isLoudMode': isLoudMode ? 1 : 0,
    'repeatType': repeatType?.toString(),
    'intervalMinutes': intervalMinutes,
    'qrCodeData': qrCodeData,
    'ringtonePath': ringtonePath,
    'notificationId': notificationId,
    'volumeLevel': volumeLevel,
    'missionPayload': missionPayload, // Add this line
  };

  factory StudyAlarm.fromJson(Map<String, dynamic> json) => StudyAlarm(
    id: json['id'],
    time: DateTime.parse(json['time']),
    title: json['title'],
    missionType: AlarmMissionType.values.firstWhere((e) => e.toString() == json['missionType']),
    missionDifficulty: json['missionDifficulty'] ?? 20,
    isActive: json['isActive'] == 1,
    isLoudMode: json['isLoudMode'] == 1,
      repeatType: json['repeatType'] != null ? RepeatType.values.firstWhere((e) => e.toString() == json['repeatType']) : null,
      intervalMinutes: json['intervalMinutes'],
      qrCodeData: json['qrCodeData'],
      ringtonePath: json['ringtonePath'],
      notificationId: json['notificationId'],
      volumeLevel: (json['volumeLevel'] ?? 0.8).toDouble(),
      missionPayload: json['missionPayload'], // Add this line
    );
}

enum AlarmMissionType {
  math,
  memory,
  maze,
  shake,
  steps,
  qrCode,
  colorTiles,
  typing,
}

class Countdown {
  String id;
  String title;
  DateTime targetDate;
  String? subject;
  bool isPaused;
  DateTime? pausedAt;
  int? pausedDuration;

  Countdown({
    required this.id,
    required this.title,
    required this.targetDate,
    this.subject,
    this.isPaused = false,
    this.pausedAt,
    this.pausedDuration,
  });

  Duration get remaining {
    if (isPaused && pausedAt != null && pausedDuration != null) {
      return Duration(seconds: pausedDuration!);
    }
    return targetDate.difference(DateTime.now());
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'targetDate': targetDate.toIso8601String(),
    'subject': subject,
    'isPaused': isPaused ? 1 : 0,
    'pausedAt': pausedAt?.toIso8601String(),
    'pausedDuration': pausedDuration,
  };

  factory Countdown.fromJson(Map<String, dynamic> json) => Countdown(
    id: json['id'],
    title: json['title'],
    targetDate: DateTime.parse(json['targetDate']),
    subject: json['subject'],
    isPaused: json['isPaused'] == 1,
    pausedAt: json['pausedAt'] != null ? DateTime.parse(json['pausedAt']) : null,
    pausedDuration: json['pausedDuration'],
  );
}

class AppBlockRule {
  String id;
  String packageName;
  String appName;
  int dailyLimitMinutes;
  List<TimeSlot> blockedTimeSlots;
  bool isStrictMode;
  int puzzleCount;
  bool isWhitelisted;

  AppBlockRule({
    required this.id,
    required this.packageName,
    required this.appName,
    this.dailyLimitMinutes = 0,
    this.blockedTimeSlots = const [],
    this.isStrictMode = false,
    this.puzzleCount = 20,
    this.isWhitelisted = false,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'packageName': packageName,
    'appName': appName,
    'dailyLimitMinutes': dailyLimitMinutes,
    'blockedTimeSlots': blockedTimeSlots.map((s) => s.toJson()).toList(),
    'isStrictMode': isStrictMode ? 1 : 0,
    'puzzleCount': puzzleCount,
    'isWhitelisted': isWhitelisted ? 1 : 0,
  };

  factory AppBlockRule.fromJson(Map<String, dynamic> json) => AppBlockRule(
    id: json['id'],
    packageName: json['packageName'],
    appName: json['appName'],
    dailyLimitMinutes: json['dailyLimitMinutes'] ?? 0,
    blockedTimeSlots: (json['blockedTimeSlots'] as List?)?.map((s) => TimeSlot.fromJson(s)).toList() ?? [],
    isStrictMode: json['isStrictMode'] == 1,
    puzzleCount: json['puzzleCount'] ?? 20,
    isWhitelisted: json['isWhitelisted'] == 1,
  );
}

class TimeSlot {
  int startHour;
  int startMinute;
  int endHour;
  int endMinute;

  TimeSlot({
    required this.startHour,
    required this.startMinute,
    required this.endHour,
    required this.endMinute,
  });

  Map<String, dynamic> toJson() => {
    'startHour': startHour,
    'startMinute': startMinute,
    'endHour': endHour,
    'endMinute': endMinute,
  };

  factory TimeSlot.fromJson(Map<String, dynamic> json) => TimeSlot(
    startHour: json['startHour'],
    startMinute: json['startMinute'],
    endHour: json['endHour'],
    endMinute: json['endMinute'],
  );
}

class TaskFailure {
  String id;
  String taskId;
  DateTime date;
  String reason;
  String? promiseType;
  String? promiseDetails;
  bool isPromiseFulfilled;
  DateTime? promiseDeadline;

  TaskFailure({
    required this.id,
    required this.taskId,
    required this.date,
    required this.reason,
    this.promiseType,
    this.promiseDetails,
    this.isPromiseFulfilled = false,
    this.promiseDeadline,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'taskId': taskId,
    'date': date.toIso8601String(),
    'reason': reason,
    'promiseType': promiseType,
    'promiseDetails': promiseDetails,
    'isPromiseFulfilled': isPromiseFulfilled ? 1 : 0,
    'promiseDeadline': promiseDeadline?.toIso8601String(),
  };

  factory TaskFailure.fromJson(Map<String, dynamic> json) => TaskFailure(
    id: json['id'],
    taskId: json['taskId'],
    date: DateTime.parse(json['date']),
    reason: json['reason'],
    promiseType: json['promiseType'],
    promiseDetails: json['promiseDetails'],
    isPromiseFulfilled: json['isPromiseFulfilled'] == 1,
    promiseDeadline: json['promiseDeadline'] != null ? DateTime.parse(json['promiseDeadline']) : null,
  );
}

class UserPoints {
  int totalPoints;
  List<String> unlockedThemes;
  List<String> earnedBadges;
  int currentStreak;
  int longestStreak;

  UserPoints({
    this.totalPoints = 0,
    this.unlockedThemes = const [],
    this.earnedBadges = const [],
    this.currentStreak = 0,
    this.longestStreak = 0,
  });

  Map<String, dynamic> toJson() => {
    'totalPoints': totalPoints,
    'unlockedThemes': unlockedThemes,
    'earnedBadges': earnedBadges,
    'currentStreak': currentStreak,
    'longestStreak': longestStreak,
  };

  factory UserPoints.fromJson(Map<String, dynamic> json) => UserPoints(
    totalPoints: json['totalPoints'] ?? 0,
    unlockedThemes: List<String>.from(json['unlockedThemes'] ?? []),
    earnedBadges: List<String>.from(json['earnedBadges'] ?? []),
    currentStreak: json['currentStreak'] ?? 0,
    longestStreak: json['longestStreak'] ?? 0,
  );
}

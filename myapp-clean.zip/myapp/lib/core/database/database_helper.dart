import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'models.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('study_tracker.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future<Database> initDatabase() async {
    return await database;
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE tasks (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        createdAt TEXT NOT NULL,
        dueDate TEXT,
        completedAt TEXT,
        estimatedMinutes INTEGER DEFAULT 0,
        actualMinutes INTEGER,
        isCompleted INTEGER DEFAULT 0,
        isPinned INTEGER DEFAULT 0,
        isUrgent INTEGER DEFAULT 0,
        colorCode TEXT DEFAULT '#2196F3',
        category TEXT DEFAULT 'Study',
        subject TEXT,
        repeatType TEXT,
        repeatCustom TEXT,
        iconName TEXT,
        focusTimerMinutes INTEGER DEFAULT 25,
        alarmId TEXT,
        attachmentPath TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE subtasks (
        id TEXT PRIMARY KEY,
        taskId TEXT NOT NULL,
        title TEXT NOT NULL,
        isCompleted INTEGER DEFAULT 0,
        FOREIGN KEY (taskId) REFERENCES tasks (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE routines (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        profileType TEXT NOT NULL,
        isActive INTEGER DEFAULT 0,
        createdAt TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE routine_blocks (
        id TEXT PRIMARY KEY,
        routineId TEXT NOT NULL,
        title TEXT NOT NULL,
        startHour INTEGER NOT NULL,
        startMinute INTEGER NOT NULL,
        durationMinutes INTEGER NOT NULL,
        type TEXT NOT NULL,
        isBlocked INTEGER DEFAULT 0,
        isCompleted INTEGER DEFAULT 0,
        FOREIGN KEY (routineId) REFERENCES routines (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE diary_entries (
        id TEXT PRIMARY KEY,
        date TEXT NOT NULL UNIQUE,
        morningNote TEXT,
        eveningNote TEXT,
        photoPaths TEXT,
        mood TEXT,
        totalStudyMinutes INTEGER DEFAULT 0,
        completedTasksCount INTEGER DEFAULT 0,
        missedTasksCount INTEGER DEFAULT 0,
        isLocked INTEGER DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE alarms (
        id TEXT PRIMARY KEY,
        time TEXT NOT NULL,
        title TEXT NOT NULL,
        missionType TEXT NOT NULL,
        missionDifficulty INTEGER DEFAULT 20,
        isActive INTEGER DEFAULT 1,
        isLoudMode INTEGER DEFAULT 0,
        repeatType TEXT,
        intervalMinutes INTEGER,
        qrCodeData TEXT,
        ringtonePath TEXT,
        notificationId INTEGER,
        volumeLevel REAL DEFAULT 0.8
      )
    ''');

    await db.execute('''
      CREATE TABLE countdowns (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        targetDate TEXT NOT NULL,
        subject TEXT,
        isPaused INTEGER DEFAULT 0,
        pausedAt TEXT,
        pausedDuration INTEGER
      )
    ''');

    await db.execute('''
      CREATE TABLE app_block_rules (
        id TEXT PRIMARY KEY,
        packageName TEXT NOT NULL,
        appName TEXT NOT NULL,
        dailyLimitMinutes INTEGER DEFAULT 0,
        isStrictMode INTEGER DEFAULT 0,
        puzzleCount INTEGER DEFAULT 20,
        isWhitelisted INTEGER DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE time_slots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        appBlockRuleId TEXT NOT NULL,
        startHour INTEGER NOT NULL,
        startMinute INTEGER NOT NULL,
        endHour INTEGER NOT NULL,
        endMinute INTEGER NOT NULL,
        FOREIGN KEY (appBlockRuleId) REFERENCES app_block_rules (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE task_failures (
        id TEXT PRIMARY KEY,
        taskId TEXT NOT NULL,
        date TEXT NOT NULL,
        reason TEXT NOT NULL,
        promiseType TEXT,
        promiseDetails TEXT,
        isPromiseFulfilled INTEGER DEFAULT 0,
        promiseDeadline TEXT,
        FOREIGN KEY (taskId) REFERENCES tasks (id)
      )
    ''');

    await db.execute('''
      CREATE TABLE user_points (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        totalPoints INTEGER DEFAULT 0,
        unlockedThemes TEXT,
        earnedBadges TEXT,
        currentStreak INTEGER DEFAULT 0,
        longestStreak INTEGER DEFAULT 0
      )
    ''');

    await db.execute('CREATE INDEX idx_tasks_dueDate ON tasks(dueDate)');
    await db.execute('CREATE INDEX idx_tasks_isCompleted ON tasks(isCompleted)');
    await db.execute('CREATE INDEX idx_diary_date ON diary_entries(date)');
  }

  Future<String> insertTask(Task task) async {
    final db = await database;
    await db.insert('tasks', task.toJson(), conflictAlgorithm: ConflictAlgorithm.replace);
    return task.id;
  }

  Future<List<Task>> getTasks({DateTime? date, bool? completed}) async {
    final db = await database;
    String query = 'SELECT * FROM tasks';
    List<String> whereClauses = [];
    List<dynamic> args = [];

    if (date != null) {
      whereClauses.add('date(dueDate) = date(?)');
      args.add(date.toIso8601String());
    }

    if (completed != null) {
      whereClauses.add('isCompleted = ?');
      args.add(completed ? 1 : 0);
    }

    if (whereClauses.isNotEmpty) {
      query += ' WHERE ${whereClauses.join(' AND ')}';
    }

    query += ' ORDER BY isPinned DESC, dueDate ASC';

    final List<Map<String, dynamic>> maps = await db.rawQuery(query, args);
    
    return maps.map((map) {
      final task = Task.fromJson(map);
      task.attachmentPath = map['attachmentPath'] as String?;
      return task;
    }).toList();
  }

  Future<void> updateTask(Task task) async {
    final db = await database;
    await db.update('tasks', task.toJson(), where: 'id = ?', whereArgs: [task.id]);
  }

  Future<void> deleteTask(String id) async {
    final db = await database;
    await db.delete('tasks', where: 'id = ?', whereArgs: [id]);
  }
  
  Future<List<Subtask>> getSubtasksForTask(String taskId) async {
    final db = await database;
    final maps = await db.query(
      'subtasks',
      where: 'taskId = ?',
      whereArgs: [taskId],
    );
    return maps.map((m) => Subtask.fromJson(m)).toList();
  }

  Future<void> insertSubtask(Subtask subtask, String taskId) async {
    final db = await database;
    await db.insert('subtasks', {
      'id': subtask.id,
      'taskId': taskId,
      'title': subtask.title,
      'isCompleted': subtask.isCompleted ? 1 : 0,
    });
  }

  Future<void> updateSubtask(Subtask subtask) async {
    final db = await database;
    await db.update('subtasks', subtask.toJson(), where: 'id = ?', whereArgs: [subtask.id]);
  }

  Future<void> deleteSubtask(String id) async {
    final db = await database;
    await db.delete('subtasks', where: 'id = ?', whereArgs: [id]);
  }

  Future<String> insertRoutine(Routine routine) async {
    final db = await database;
    await db.insert('routines', {
      'id': routine.id,
      'name': routine.name,
      'profileType': routine.profileType,
      'isActive': routine.isActive ? 1 : 0,
      'createdAt': routine.createdAt.toIso8601String(),
    });

    for (var block in routine.blocks) {
      await db.insert('routine_blocks', {
        'id': block.id,
        'routineId': routine.id,
        'title': block.title,
        'startHour': block.startHour,
        'startMinute': block.startMinute,
        'durationMinutes': block.durationMinutes,
        'type': block.type,
        'isBlocked': block.isBlocked ? 1 : 0,
        'isCompleted': block.isCompleted ? 1 : 0,
      });
    }

    return routine.id;
  }

  Future<List<Routine>> getRoutines() async {
    final db = await database;
    final maps = await db.query('routines');
    
    List<Routine> routines = [];
    for (var map in maps) {
      final routine = Routine(
        id: map['id'] as String,
        name: map['name'] as String,
        profileType: map['profileType'] as String,
        isActive: map['isActive'] == 1,
        createdAt: DateTime.parse(map['createdAt'] as String),
      );
      
      final blockMaps = await db.query(
        'routine_blocks',
        where: 'routineId = ?',
        whereArgs: [routine.id],
        orderBy: 'startHour, startMinute',
      );
      
      routine.blocks = blockMaps.map((m) => RoutineBlock(
        id: m['id'] as String,
        title: m['title'] as String,
        startHour: m['startHour'] as int,
        startMinute: m['startMinute'] as int,
        durationMinutes: m['durationMinutes'] as int,
        type: m['type'] as String,
        isBlocked: m['isBlocked'] == 1,
        isCompleted: m['isCompleted'] == 1,
      )).toList();
      
      routines.add(routine);
    }
    
    return routines;
  }

  Future<String> insertDiaryEntry(DiaryEntry entry) async {
    final db = await database;
    await db.insert('diary_entries', {
      'id': entry.id,
      'date': entry.date.toIso8601String(),
      'morningNote': entry.morningNote,
      'eveningNote': entry.eveningNote,
      'photoPaths': entry.photoPaths.join(','),
      'mood': entry.mood,
      'totalStudyMinutes': entry.totalStudyMinutes,
      'completedTasksCount': entry.completedTasksCount,
      'missedTasksCount': entry.missedTasksCount,
      'isLocked': entry.isLocked ? 1 : 0,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
    return entry.id;
  }

  Future<DiaryEntry?> getDiaryEntry(DateTime date) async {
    final db = await database;
    final maps = await db.query(
      'diary_entries',
      where: 'date(date) = date(?)',
      whereArgs: [date.toIso8601String()],
    );
    
    if (maps.isEmpty) return null;
    
    final map = maps.first;
    return DiaryEntry(
      id: map['id'] as String,
      date: DateTime.parse(map['date'] as String),
      morningNote: map['morningNote'] as String?,
      eveningNote: map['eveningNote'] as String?,
      photoPaths: (map['photoPaths'] as String?)?.split(',') ?? [],
      mood: map['mood'] as String?,
      totalStudyMinutes: map['totalStudyMinutes'] as int? ?? 0,
      completedTasksCount: map['completedTasksCount'] as int? ?? 0,
      missedTasksCount: map['missedTasksCount'] as int? ?? 0,
      isLocked: map['isLocked'] == 1,
    );
  }

  Future<List<DiaryEntry>> searchDiaryEntries(String query) async {
    final db = await database;
    final maps = await db.query(
      'diary_entries',
      where: 'morningNote LIKE ? OR eveningNote LIKE ?',
      whereArgs: ['%$query%', '%$query%'],
    );

    return maps.map((m) => DiaryEntry.fromJson(m)).toList();
  }

  Future<String> insertAlarm(StudyAlarm alarm) async {
    final db = await database;
    await db.insert('alarms', alarm.toJson());
    return alarm.id;
  }
  
  Future<void> updateAlarm(StudyAlarm alarm) async {
    final db = await database;
    await db.update('alarms', alarm.toJson(), where: 'id = ?', whereArgs: [alarm.id]);
  }

  Future<void> deleteAlarm(String id) async {
    final db = await database;
    await db.delete('alarms', where: 'id = ?', whereArgs: [id]);
  }


  Future<List<StudyAlarm>> getAlarms() async {
    final db = await database;
    final maps = await db.query('alarms', where: 'isActive = 1');
    
    return maps.map((m) => StudyAlarm.fromJson(m)).toList();
  }

  Future<String> insertCountdown(Countdown countdown) async {
    final db = await database;
    await db.insert('countdowns', countdown.toJson());
    return countdown.id;
  }

  Future<List<Countdown>> getCountdowns() async {
    final db = await database;
    final maps = await db.query('countdowns');
    
    return maps.map((m) => Countdown.fromJson(m)).toList();
  }

  Future<String> insertAppBlockRule(AppBlockRule rule) async {
    final db = await database;
    await db.insert('app_block_rules', rule.toJson());

    for (var slot in rule.blockedTimeSlots) {
      await db.insert('time_slots', {
        'appBlockRuleId': rule.id,
        'startHour': slot.startHour,
        'startMinute': slot.startMinute,
        'endHour': slot.endHour,
        'endMinute': slot.endMinute,
      });
    }

    return rule.id;
  }

  Future<List<AppBlockRule>> getAppBlockRules() async {
    final db = await database;
    final maps = await db.query('app_block_rules');
    
    List<AppBlockRule> rules = [];
    for (var map in maps) {
      final rule = AppBlockRule.fromJson(map);
      
      final slotMaps = await db.query(
        'time_slots',
        where: 'appBlockRuleId = ?',
        whereArgs: [rule.id],
      );
      
      rule.blockedTimeSlots = slotMaps.map((m) => TimeSlot(
        startHour: m['startHour'] as int,
        startMinute: m['startMinute'] as int,
        endHour: m['endHour'] as int,
        endMinute: m['endMinute'] as int,
      )).toList();
      
      rules.add(rule);
    }
    
    return rules;
  }

  Future<String> insertTaskFailure(TaskFailure failure) async {
    final db = await database;
    await db.insert('task_failures', failure.toJson());
    return failure.id;
  }

  Future<Map<String, dynamic>> exportAllData() async {
    final db = await database;
    return {
      'tasks': await db.query('tasks'),
      'subtasks': await db.query('subtasks'),
      'routines': await db.query('routines'),
      'routine_blocks': await db.query('routine_blocks'),
      'diary_entries': await db.query('diary_entries'),
      'alarms': await db.query('alarms'),
      'countdowns': await db.query('countdowns'),
      'app_block_rules': await db.query('app_block_rules'),
      'time_slots': await db.query('time_slots'),
      'task_failures': await db.query('task_failures'),
    };
  }

  Future<void> close() async {
    final db = await database;
    await db.close();
  }
}

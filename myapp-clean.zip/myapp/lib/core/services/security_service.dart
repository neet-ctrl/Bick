import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SecurityService {
  static final SecurityService instance = SecurityService._init();
  final LocalAuthentication _localAuth = LocalAuthentication();

  SecurityService._init();

  Future<bool> authenticate(String reason) async {
    try {
      final canCheck = await _localAuth.canCheckBiometrics;
      if (!canCheck) {
        // Fallback to PIN
        return await _showPinDialog(reason);
      }

      return await _localAuth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(
          biometricOnly: false,
          stickyAuth: true,
        ),
      );
    } catch (e) {
      return await _showPinDialog(reason);
    }
  }

  Future<bool> _showPinDialog(String reason) async {
    // In real implementation, show PIN input dialog
    // For now, return true as placeholder
    return true;
  }

  Future<void> setAppLock(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('app_lock_enabled', enabled);
  }

  Future<bool> isAppLockEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('app_lock_enabled') ?? false;
  }
}


import 'dart:convert';
import 'package:encrypt/encrypt.dart';
import 'package:shared_preferences/shared_preferences.dart';

class EncryptionService {
  static final EncryptionService instance = EncryptionService._init();
  late Encrypter _encrypter;
  late IV _iv;
  bool _initialized = false;

  EncryptionService._init();

  Future<void> _initEncryption() async {
    if (_initialized) return;

    final prefs = await SharedPreferences.getInstance();
    String? keyString = prefs.getString('encryption_key');
    
    final key = Key.fromBase64(keyString);
    _encrypter = Encrypter(AES(key));
    _iv = IV.fromLength(16);
    _initialized = true;
  }

  Future<String> encrypt(String plainText) async {
    await _initEncryption();
    final encrypted = _encrypter.encrypt(plainText, iv: _iv);
    return encrypted.base64;
  }

  Future<String> decrypt(String encryptedText) async {
    await _initEncryption();
    try {
      final encrypted = Encrypted.fromBase64(encryptedText);
      return _encrypter.decrypt(encrypted, iv: _iv);
    } catch (e) {
      return encryptedText; // Return as-is if decryption fails
    }
  }

  Future<String> encryptJson(Map<String, dynamic> data) async {
    final jsonString = jsonEncode(data);
    return encrypt(jsonString);
  }

  Future<Map<String, dynamic>> decryptJson(String encryptedData) async {
    final decrypted = await decrypt(encryptedData);
    return jsonDecode(decrypted) as Map<String, dynamic>;
  }
}
